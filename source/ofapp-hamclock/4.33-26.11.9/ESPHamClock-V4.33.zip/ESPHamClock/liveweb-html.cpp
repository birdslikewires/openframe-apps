/* this is the html that runs in a browser showing a live hamclock connection.
 * the basic idea is to start with a complete image then continuously poll for incremental changes.
 * this page is loaded first with all subsequent communication via a websocket.
 * ESP is far too slow reading pixels to make this practical.
 */

#include "HamClock.h"

#if defined (_IS_UNIX)

char live_html[] =  R"_raw_html_(
<!DOCTYPE html>
<html>

<head>

    <!-- this might help iOS safari run full screen -->
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />

    <title>
        HamClock Live!
    </title>
    
    <style>

        #hamclock-cvs {
            touch-action: pinch-zoom; /* allow both 1-finger moves and multi-touch p-z */
        }

        /* overlay used to show an embedded page in-app (e.g. ADS-B Exchange), instead of a
         * new tab. covers most of the canvas but leaves a visible margin so it's clearly a
         * popup, not a navigation away from HamClock. */
        #embed-overlay {
            display: none;              /* toggled to flex by showEmbed() */
            position: fixed;
            left: 3%; top: 3%; right: 3%; bottom: 3%;
            flex-direction: column;
            background: #111;
            border: 1px solid #888;
            box-shadow: 0 0 20px rgba(0,0,0,0.7);
            z-index: 1000;
        }

        #embed-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 6px 10px;
            background: #222;
            color: #eee;
            font-family: sans-serif;
            font-size: 14px;
            border-bottom: 1px solid #888;
        }

        #embed-title {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            flex: 1;
        }

        #embed-header button {
            margin-left: 8px;
            background: #333;
            color: #eee;
            border: 1px solid #888;
            border-radius: 3px;
            padding: 4px 10px;
            font-size: 13px;
            cursor: pointer;
        }

        #embed-header button:hover {
            background: #444;
        }

        #embed-frame {
            flex: 1;
            width: 100%;
            border: none;
            background: white;
        }

        /* shown if the embedded site appears not to have loaded (likely blocked by the
         * target's own framing policy) -- points the user at the manual fallback button
         * instead of silently leaving a blank frame. */
        #embed-fallback-note {
            display: none;
            padding: 6px 10px;
            background: #442;
            color: #fd8;
            font-family: sans-serif;
            font-size: 12px;
            border-bottom: 1px solid #888;
        }

        #virtual-cursor {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 28px;
            height: 28px;
            pointer-events: none;
            z-index: 9999;
            transform: translate3d(-100px, -100px, 0);
            transition: opacity 0.25s ease, transform 0.05s ease-out;
            filter: drop-shadow(0 2px 5px rgba(0,0,0,0.85));
        }
        #virtual-cursor.clicking {
            transform: scale(0.85);
        }

    </style>

    <script>

        // config
        const UPDATE_MS = 100;          // update interval
        const MOUSE_JITTER = 5;         // allow this much mouse motion for a touch
        const LONGPRESS_MS = 500;       // press and hold duration in ms to trigger tooltip
        const APP_W = 800;              // app coord system width
        const nonan_chars =             // supported non-alnum chars
          ['Tab', 'Enter', 'Space', 'Escape', 'Backspace', 'ArrowLeft', 'ArrowDown', 'ArrowUp', 'ArrowRight', 'Delete'];
        const RELOAD_KEY = "reload";    // sessionStorage key to manage reloads

        // state
        var ws;                         // Websocket
        var ws_abdata = 0;              // ws onmessage header capture
        var drawing_verbose = 0;        // > 0 for more info about drawing
        var ws_verbose = 0;             // > 0 for more info about websocket commands
        var event_verbose = 0;          // > 0 for more info about keyboard or pointer activity
        var prev_regnhdr;               // for erasing if drawing_verbose > 1
        var app_scale = 0;              // size factor -- set for real when get first whole image
        var pointerdown_x = 0;          // location of pointerdown event
        var pointerdown_y = 0;          // location of pointerdown event
        var pointermove_ms = 0;         // Date.now when pointermove event
        var longpress_timer = null;     // timer for long-press detection
        var longpress_fired = false;    // whether long-press triggered tooltip
        var want_fs, tried_fs;          // whether user wants full screen and has succeeded once
        var wsclose_reload = 1;         // whether to reload if lose ws connection
        var cvs, ctx;                   // handy

        // virtual cursor state for remote control / D-pad
        var vcursor_el = null;
        var vcursor_x = APP_W / 2;      // app coords x (init 400)
        var vcursor_y = 240;            // app coords y (init 240)
        var vcursor_visible = false;
        var vcursor_hide_timer = null;
        var last_arrow_ms = 0;
        var arrow_repeat_count = 0;
        const VCURSOR_HIDE_MS = 12000;  // auto-hide after 12s of inactivity

        function isOverSettings(domX, domY) {
            if (!window.AndroidApp) return false;
            if (domX === undefined || domY === undefined) {
                if (!cvs || !app_scale) return false;
                const rect = cvs.getBoundingClientRect();
                domX = rect.left + vcursor_x * app_scale;
                domY = rect.top + vcursor_y * app_scale;
            }
            const win_w = window.innerWidth;
            const win_h = window.innerHeight;
            const nearDomEdge = (domX >= win_w - 75 && domY >= win_h - 75);
            const nearCanvasEdge = (vcursor_x >= APP_W - 35 && vcursor_y >= 445);
            return nearDomEdge || nearCanvasEdge;
        }

        function updateVirtualCursorDom() {
            if (!vcursor_el || !cvs || !app_scale) return;
            const rect = cvs.getBoundingClientRect();
            const domX = rect.left + vcursor_x * app_scale;
            const domY = rect.top + vcursor_y * app_scale;
            vcursor_el.style.transform = 'translate3d(' + Math.round(domX) + 'px, ' + Math.round(domY) + 'px, 0px)';

            if (window.AndroidApp && typeof window.AndroidApp.setSettingsHover === 'function') {
                window.AndroidApp.setSettingsHover(isOverSettings(domX, domY));
            }
        }

        function showVirtualCursor() {
            if (!vcursor_el) return;
            vcursor_el.style.display = 'block';
            vcursor_visible = true;
            updateVirtualCursorDom();
            resetVirtualCursorTimer();
        }

        function hideVirtualCursor() {
            if (!vcursor_el) return;
            vcursor_el.style.display = 'none';
            vcursor_visible = false;
            if (vcursor_hide_timer) {
                clearTimeout(vcursor_hide_timer);
                vcursor_hide_timer = null;
            }
            if (window.AndroidApp && typeof window.AndroidApp.setSettingsHover === 'function') {
                window.AndroidApp.setSettingsHover(false);
            }
        }

        function resetVirtualCursorTimer() {
            if (vcursor_hide_timer)
                clearTimeout(vcursor_hide_timer);
            vcursor_hide_timer = setTimeout(hideVirtualCursor, VCURSOR_HIDE_MS);
        }

        function handleVirtualCursorMove(direction) {
            const now = Date.now();
            let step = 6;
            if (now - last_arrow_ms < 200) {
                arrow_repeat_count++;
                if (arrow_repeat_count > 30) step = 24;
                else if (arrow_repeat_count > 18) step = 16;
                else if (arrow_repeat_count > 8) step = 10;
            } else {
                arrow_repeat_count = 0;
            }
            last_arrow_ms = now;

            // If cursor was hidden, wake it up in place on first press without moving
            if (!vcursor_visible) {
                showVirtualCursor();
                arrow_repeat_count = 0;
                sendWSMsg('set_mouse?x=' + vcursor_x + '&y=' + vcursor_y);
                return;
            }

            // Transfer focus to native Android settings button when navigating past bottom-right
            if (window.AndroidApp && typeof window.AndroidApp.focusSettings === 'function') {
                if ((direction === 'ArrowDown' || direction === 'ArrowRight') &&
                    vcursor_x >= APP_W - 35 && vcursor_y >= 445) {
                    window.AndroidApp.focusSettings();
                    return;
                }
            }

            if (direction === 'ArrowLeft') vcursor_x -= step;
            else if (direction === 'ArrowRight') vcursor_x += step;
            else if (direction === 'ArrowUp') vcursor_y -= step;
            else if (direction === 'ArrowDown') vcursor_y += step;

            // clamp to app bounds (0..799, 0..479)
            vcursor_x = Math.max(0, Math.min(APP_W - 1, vcursor_x));
            vcursor_y = Math.max(0, Math.min(479, vcursor_y));

            updateVirtualCursorDom();
            resetVirtualCursorTimer();

            // update HamClock hover position
            sendWSMsg('set_mouse?x=' + vcursor_x + '&y=' + vcursor_y);
        }

        function handleVirtualCursorClick() {
            // If cursor was hidden, wake it up in place to prevent accidental blind clicks
            if (!vcursor_visible) {
                showVirtualCursor();
                return;
            }

            // Open settings if virtual cursor is clicked over the native settings button
            if (window.AndroidApp && typeof window.AndroidApp.openSettings === 'function') {
                if (isOverSettings()) {
                    window.AndroidApp.openSettings();
                    resetVirtualCursorTimer();
                    return;
                }
            }

            // brief click feedback animation
            if (vcursor_el) {
                vcursor_el.classList.add('clicking');
                setTimeout(function() {
                    if (vcursor_el) vcursor_el.classList.remove('clicking');
                }, 120);
            }

            // send touch to HamClock
            sendWSMsg('set_touch?x=' + vcursor_x + '&y=' + vcursor_y + '&button=0');
            resetVirtualCursorTimer();
        }

        // define functions, onLoad follows near the bottom

        // request a new full image
        function getFullImage() {
            sendWSMsg ("get_live.png?");
        }

        // request an image update
        function getUpdate() {
            sendWSMsg ("get_live.bin?");
        }
        

        // given inherent hamclock build size, set canvas size and configure to stay centered
        function initCanvas (hc_w, hc_h) {
            if (drawing_verbose) {
                console.log("document.documentElement.clientWidth = " + document.documentElement.clientWidth);
                console.log("window.innerWidth = " + window.innerWidth);
                console.log ("hamclock is " +  hc_w + " x " +  hc_h);
            }

            // pixels to draw on always match the real clock size
            cvs.width =  hc_w;
            cvs.height =  hc_h;

            // get window area dimensions
            let win_w = document.documentElement.clientWidth || window.innerWidth;
            let win_h = document.documentElement.clientHeight || window.innerHeight;

            // center if HC is smaller else shrink to fit
            if (hc_w < win_w && hc_h < win_h) {

                // hc is smaller -- center in full screen
                cvs.style.width = hc_w + "px";
                cvs.style.height = hc_h + "px";

            } else {

                // hc is larger -- shrink to fit preserving aspect
                if (win_w*hc_h > win_h*hc_w) {
                    hc_w = hc_w*win_h/hc_h;
                    hc_h = win_h;
                } else {
                    hc_h = hc_h*win_w/hc_w;
                    hc_w = win_w;
                }
                cvs.style.width = hc_w + "px";
                cvs.style.height = hc_h + "px";
            }

            // center 
            cvs.style.position = 'absolute';
            cvs.style.top = "50%";
            cvs.style.left = "50%";
            cvs.style.margin = (-hc_h/2) + "px" + " 0 0 " + (-hc_w/2) + "px"; // trbl
            app_scale = hc_w/APP_W;
            updateVirtualCursorDom();

            if (drawing_verbose)
                console.log ("canvas is " + hc_w + " x " + hc_h + " app_scale " + app_scale);
        }

        // display the given full png uint8
        function drawFullImage (png8) {

            var pngbl = new Blob ([png8], {type:"image/png"});
            createImageBitmap (pngbl)
            .then(function(ibm) {
                if (drawing_verbose)
                    console.log ("drawFullImage size " + ibm.width + " x " + ibm.height);
                initCanvas(ibm.width, ibm.height);
                ctx.drawImage(ibm, 0, 0);
            })
            .catch(function(err){
                console.log("full image promise err: " + err);
            });
        }

        // update given header and png sprites image -- see liveweb.cpp::updateExistingClient()
        function drawUpdate (hdr8, png8) {

            // extract 4-byte header preamble
            const blok_w = hdr8[0];                         // block width, pixels
            const blok_h = hdr8[1];                         // block width, pixels
            const n_regn = (hdr8[2] << 8) | hdr8[3];        // total n blocks wide, MSB LSB

            if (drawing_verbose > 1) {
                // erase, or at least unmark, previous marked regions
                if (prev_regnhdr) {
                    ctx.strokeStyle = "black";
                    ctx.beginPath();
                    for (let i = 0; i < prev_regnhdr.length; i++) {
                        const cvs_x = prev_regnhdr[4+3*i] * blok_w;
                        const cvs_y = prev_regnhdr[5+3*i] * blok_h;
                        const cvs_w = prev_regnhdr[6+3*i] * blok_w;
                        ctx.rect (cvs_x, cvs_y, cvs_w, blok_h);
                    }
                    ctx.stroke();
                }
                // save for next time
                prev_regnhdr = hdr8.slice(0,4+3*n_regn);
            }

            // walk down remainder of header and draw each region
            if (n_regn > 0) {
                // png8 is one image blok_h hi of n_regns contiguous regions each variable width
                let pngbl = new Blob ([png8], {type:"image/png"});
                createImageBitmap (pngbl)
                .then(function(ibm) {
                    // render each region.
                    let regn_x = 0;                         // walk region x along img
                    let n_draw = 0;                         // count n drawn regions just for stat
                    for (let i = 0; i < n_regn; i++) {
                        const cvs_x = hdr8[4+3*i] * blok_w; // ul corner x in canvas pixels
                        const cvs_y = hdr8[5+3*i] * blok_h; // ul corner y in canvas pixels
                        const n_long = hdr8[6+3*i];         // n regions long
                        const cvs_w = n_long * blok_w;      // total region width in canvas pixels
                        ctx.drawImage (ibm, regn_x, 0, cvs_w, blok_h, cvs_x, cvs_y, cvs_w, blok_h);

                        if (drawing_verbose > 1) {
                            // mark updated regions
                            if (drawing_verbose > 2)
                                console.log (regn_x + " : " + cvs_x + "," + cvs_y + " "
                                                    + cvs_w + "x" + blok_h);
                            ctx.strokeStyle = "red";
                            ctx.beginPath();
                            ctx.rect (cvs_x, cvs_y, cvs_w, blok_h);
                            ctx.stroke();
                        }

                        regn_x += cvs_w;                    // next region
                        n_draw += n_long;
                    }
                    if (drawing_verbose)
                        console.log ("  drawUpdate " + hdr8.byteLength + "B " +
                                    n_regn + "/" + n_draw + " of " + blok_w + " x " + blok_h);

                })
                .catch(function(err) {
                    console.log("update promise err: ", err);
                    runSoon (getFullImage);
                });
            }

        }

        // schedule func() soon
        var upd_tid = 0;                            // update pacing timer id
        function runSoon (func) {

            // insure no nested requests
            if (upd_tid) {
                if (ws_verbose)
                    console.log ("cancel pending timer");
                clearTimeout(upd_tid);
            }

            // register callback
            upd_tid = setTimeout (function(){upd_tid = 0; func();}, UPDATE_MS);
            if (ws_verbose)
                console.log ("setting timer for " + func.name + " in " + UPDATE_MS + " ms");
        }

        // given any pointer event return coords with respect to canvas scaled to application.
        // returns undefined if scaling factor is not yet known.
        function getAppCoords (event) {

            if (app_scale) {
                const rect = cvs.getBoundingClientRect();
                const x = Math.round((event.clientX - rect.left)/app_scale);
                const y = Math.round((event.clientY - rect.top)/app_scale);
                return ({x, y});
            }
        }

        // send the given key and optionl control and shift modifier codes to the hamclock
        function sendKey (k, c, s) {

            // a real space would send 'char= ' which doesn't parse so we invent Space name
            if (k === ' ')
                k = 'Space';

            // map keypad Decimal/Separator key names to decimal point
            if (k === 'Decimal' || k === 'Separator')
                k = '.';

            // accept only certain non-alphanumeric keys
            if ((k.length == 1 && (k.charCodeAt(0) < 33 || k.charCodeAt(0) > 126))
                            || (k.length > 1 && !nonan_chars.find (e => { if (e == k) return true; }))) {
                if (event_verbose)
                    console.log('ignoring ' + k);
                return;
            }
            
            // package up and send: single characters sent as 0xHEX so symbols (&, =, #, +, %, etc) don't collide with URL query syntax
            var char_val = (k.length == 1) ? ('0x' + k.charCodeAt(0).toString(16).toUpperCase()) : k;
            var msg = 'set_char?char=' + char_val + '&mod=';
            if (c)
                msg += 'C';
            if (s)
                msg += 'S';
            if (event_verbose)
                console.log('sending ' + msg);
            sendWSMsg (msg);
        }


        // connect keydown to send character to hamclock, beware ctrl keys and browser interactions
        window.addEventListener('keydown', function(event) {

            if (event_verbose)
                console.log('keydown: ', event);

            // now that user has done something check if they want to go full screen
            checkFullScreen();

            // handy
            var key = event.key;
            if (event.code === "NumpadDecimal" && key === ",")
                key = ".";

            // ignore meta
            if (event.metaKey) {
                if (event_verbose)
                    console.log('ignoring ' + key);
                return;
            }

            // Escape key closes embed overlay if open
            if (key === "Escape") {
                var overlay = document.getElementById ('embed-overlay');
                if (overlay && overlay.style.display !== 'none') {
                    hideEmbed();
                    event.preventDefault();
                    return;
                }
            }

            // don't let browser see tab
            if (key === "Tab") {
                if (event_verbose)
                    console.log ("stopping tab");
                event.preventDefault();
            }

            // ignore Ctrl+V / Cmd+V here so browser's native 'paste' event handles it without typing a stray 'v'
            if ((event.ctrlKey || event.metaKey) && (key === 'v' || key === 'V')) {
                if (event_verbose)
                    console.log ("delegating Ctrl+V to paste event");
                return;
            }

            sendKey (key, event.ctrlKey, event.shiftKey);
        });

        // respond to mobile device being rotated. resize seems to work better than orientationchange
        // window.addEventListener("orientationchange", function(event) {
        window.addEventListener("resize", function(event) {
            if (event_verbose)
                console.log ("resize event");
            // get full image to establish new screen size
            runSoon (getFullImage);
        });

        // show _one_ simple stand-alone message
        var msg_drawn;
        function drawMsgOnce (msg) {
            if (!msg_drawn) {
                console.log (msg);
                ctx.fillStyle = "black";
                ctx.fillRect (0, 0, 10000, 10000);
                ctx.fillStyle = "orange";
                ctx.font = "25px sans-serif";
                ctx.fillText (msg, 50, 50);
                msg_drawn = 1;
            }
        }


        // reload this page a few times, presumably hamclock was restarted but don't try forever
        function reloadThisPage() {

            // use sessionStorage to detect reloading
            var s = sessionStorage.getItem (RELOAD_KEY);

            if (s) {

                // already loaded once, just report without restart but remove key to allow manual reloading
                sessionStorage.removeItem (RELOAD_KEY);
                drawMsgOnce ("No connection");

            } else {

                // record key so we can detect subsequent reload
                sessionStorage.setItem (RELOAD_KEY, "one");

                console.log ('* reloading');
                setTimeout (function() {
                    try {
                        window.location.reload(true);
                    } catch(err) {
                        console.log('* reload err: ' + err);
                    }
                }, 3000);               // setup waits for 10 seconds

            }
        }



        // send the given message over the websocket
        function sendWSMsg (msg) {
            if (ws.readyState != 1) {
                setTimeout (sendWSMsg, 500, msg);
            } else {
                if (ws_verbose)
                    console.log ('sendWSMsg: ' + msg);
                ws.send (msg);
            }
        }

        // show the given url in the in-page embed overlay instead of a new tab.
        //
        // N.B. cross-origin iframes give JS no reliable way to detect whether the target site
        // actually rendered or silently refused via X-Frame-Options/CSP frame-ancestors -- we
        // can't inspect contentDocument across origins, and a refused frame still fires 'load'
        // in most browsers. So this doesn't try to auto-detect failure and auto-redirect: an
        // automatic window.open() from a timer callback is a non-user-gesture popup anyway and
        // gets blocked by the browser's popup blocker in practice. Instead: the "Open in new
        // tab" button is always visible up front, and a one-time hint banner appears a few
        // seconds in as a nudge in case the frame is sitting blank.
        var embed_hint_timer = null;
        function showEmbed (url) {
            document.getElementById ('embed-frame').src = url;
            document.getElementById ('embed-title').textContent = url;
            document.getElementById ('embed-fallback-note').style.display = 'none';
            document.getElementById ('embed-overlay').style.display = 'flex';

            if (embed_hint_timer)
                clearTimeout (embed_hint_timer);
            embed_hint_timer = setTimeout (function() {
                document.getElementById ('embed-fallback-note').style.display = 'block';
            }, 4000);

            var closeBtn = document.getElementById ('embed-close-btn');
            if (closeBtn)
                closeBtn.focus();
            if (window.AndroidApp && window.AndroidApp.setEmbedVisible)
                window.AndroidApp.setEmbedVisible(true);
        }

        function hideEmbed () {
            document.getElementById ('embed-overlay').style.display = 'none';
            document.getElementById ('embed-frame').src = 'about:blank';   // stop it running in bg
            if (embed_hint_timer) {
                clearTimeout (embed_hint_timer);
                embed_hint_timer = null;
            }
            if (window.AndroidApp && window.AndroidApp.setEmbedVisible)
                window.AndroidApp.setEmbedVisible(false);
        }

        // user gesture -- window.open() here is reliable, unlike from a timer callback
        function embedOpenNewTab () {
            var url = document.getElementById ('embed-frame').src;
            window.open (url, "HamClockTab");
            hideEmbed ();
        }

        // try once to engage full screen if desired.
        // N.B. must be called from a user action
        function checkFullScreen() {
            if (want_fs && !tried_fs) {
                console.log ("engaging FS");
                document.documentElement.requestFullscreen()
                tried_fs = true;
            }
        }

        // called one time after page has loaded
        function onLoad() {

            // create websocket back to same location replacing last component of our path with "live-ws"
            let ws_proto = (location.protocol === "https:") ? "wss://" : "ws://";       // tnx WK2X
            let ws_host = location.host + location.pathname.replace(/\/[^\/]*$/, "/live-ws");
            ws = new WebSocket ( ws_proto + ws_host);
            ws.binaryType = "arraybuffer";
            ws.onopen = function () {
                console.log('WS connection established.');
            };
            ws.onclose = function () {
                console.log('WS connection closed.');
                // reload on server die but not intentional actions
                if (wsclose_reload)
                    reloadThisPage();
            };
            ws.onerror = function (e) {
                console.log('WS connection failed: ', e);
                reloadThisPage();
            };


            // respond to hamclock messages
            ws.onmessage = function (e) {
                if (ws_verbose > 1)
                    console.log ('ws onmessage length ' + e.data.byteLength);

                if (e.data instanceof ArrayBuffer) {
                    // received whole or update image

                    var data8 = new Uint8Array (e.data);
                    if (data8[0] == 137 && data8[1] == 80 && data8[2] == 78 && data8[3] == 71) {
                        // this is a PNG image -- show whole if alone else assume its part of an update
                        if (ws_abdata) {
                            drawUpdate (new Uint8Array(ws_abdata), data8);
                            ws_abdata = 0;
                        } else {
                            drawFullImage (data8);
                            // allow restart
                            sessionStorage.removeItem (RELOAD_KEY);
                        }
                        // ask for updates regardless
                        runSoon (getUpdate);
                    } else {
                        // this is an update patch collection
                        ws_abdata = e.data;
                    }

                } else if (typeof e.data === 'string') {
                    // received text message

                    if (ws_verbose)
                        console.log ('rxWSMsg: ', e.data);

                    if (e.data === 'full-screen') {
                        // record user wants full screen, won't actually happen until they click.
                        // message arrives continuously because client can't tell if user reloaded page.
                        if (!want_fs) {
                            console.log ("user wants FS");
                            tried_fs = false;
                            want_fs = true;
                        }
                    }

                    else if (e.data.substring(0,5) == 'open ') {
                        // try to open a url in a tab
                        var url = e.data.substring(5);
                        console.log('opening ' + url);
                        if (!window.open(url, "HamClockTab")) {         // naming the tab allows reuse
                            console.log ("Failed to open ", url);
                            alert ("Failed to open " + url + ". \nYou may have popups blocked");
                        }
                    }

                    else if (e.data.substring(0,6) == 'embed ') {
                        // show a url in an in-page overlay instead of a new tab
                        var url = e.data.substring(6);
                        console.log('embedding ' + url);
                        showEmbed (url);
                    }

                    else if (e.data === 'paste') {
                        if (navigator.clipboard && navigator.clipboard.readText) {
                            navigator.clipboard.readText().then(text => {
                                if (text)
                                    pasteString(text);
                            }).catch(err => {
                                console.log("clipboard read denied: ", err);
                                let text = prompt("Paste text here (Ctrl+V):", "");
                                if (text)
                                    pasteString(text);
                            });
                        } else {
                            let text = prompt("Paste text here (Ctrl+V):", "");
                            if (text)
                                pasteString(text);
                        }
                    }

                    else if (e.data === 'Too many connections') {       // N.B. string must match liveweb.cpp
                        // close and don't reload
                        drawMsgOnce (e.data);
                        wsclose_reload = 0;
                    }

                    else if (e.data === 'Session timed out') {          // N.B. string must match liveweb.cpp
                        // close and don't reload
                        drawMsgOnce (e.data);
                        wsclose_reload = 0;
                    }


                    else
                        drawMsgOnce (e.data);

                } else {
                    console.log ("Unknown WS data: ", e.data);
                }
            }

            
            // handy access to canvas and drawing context
            cvs = document.getElementById('hamclock-cvs');
            ctx = cvs.getContext('2d', { alpha: false });       // faster w/o alpha
            ctx.translate(0.5, 0.5);                            // a tiny bit less blurry?

            function cancelLongPress() {
                if (longpress_timer !== null) {
                    clearTimeout (longpress_timer);
                    longpress_timer = null;
                }
            }

            // pointerdown: record time and position, start long-press timer
            cvs.addEventListener ('pointerdown', function(event) {
                // check if user wants to go full screen
                checkFullScreen();

                // all ours
                event.preventDefault();

                const m = getAppCoords (event);
                if (!m) {
                    console.log("pointerdown: don't know app_scale yet");
                    return;
                }

                cancelLongPress();
                longpress_fired = false;

                // hide virtual cursor on real touch/pointer tap
                if (event.pointerType !== 'mouse' || event.isPrimary) {
                    hideVirtualCursor();
                }

                pointermove_ms = Date.now();
                pointerdown_x = m.x;
                pointerdown_y = m.y;
                if (event_verbose)
                    console.log ('pointer down');

                // start long-press timer for primary button/touch without modifiers
                var mods = event.ctrlKey || event.metaKey;
                if (event.button === 0 && !mods) {
                    longpress_timer = setTimeout (function() {
                        longpress_timer = null;
                        longpress_fired = true;
                        if (event_verbose)
                            console.log ('long press at ' + m.x + ',' + m.y);
                        // trigger tooltip / secondary tap (button 1)
                        sendWSMsg ('set_touch?x=' + m.x + '&y=' + m.y + '&button=1');
                    }, LONGPRESS_MS);
                }
            });

            // pointerleave: cancel long-press and send illegal mouse location 
            cvs.addEventListener ('pointerleave', function(event) {
                // all ours
                event.preventDefault();
                cancelLongPress();

                // send location well outside app
                sendWSMsg ('set_mouse?x=-1&y=-1');

            });

            // pointercancel: cancel long-press
            cvs.addEventListener ('pointercancel', function(event) {
                event.preventDefault();
                cancelLongPress();
            });

            // pointerup: send set_touch unless long-press already handled
            cvs.addEventListener ('pointerup', function(event) {
                // all ours
                event.preventDefault();
                cancelLongPress();

                if (longpress_fired) {
                    longpress_fired = false;
                    return;
                }

                // extract application coords
                const m = getAppCoords (event);
                if (!m) {
                    console.log("pointerup: don't know app_scale yet");
                    return;
                }

                // ignore if pointer moved so moves don't end with a tap
                if (Math.abs(m.x-pointerdown_x) > MOUSE_JITTER || Math.abs(m.y-pointerdown_y) > MOUSE_JITTER){
                    if (event_verbose)
                        console.log ('cancel pointerup because pointer moved');
                    return;
                }

                // code button0+mods, button1 (middle), or button2 (right) as button 1, else button 0.
                // N.B. event.button 0 means button 1 !
                var mods = event.ctrlKey || event.metaKey;
                var button = ((event.button == 0 && mods) || event.button == 1 || event.button == 2) ? 1 : 0;
                console.log ("button " + event.button + " + " + mods + " -> " + button);

                // compose and send
                let msg = 'set_touch?x=' + m.x + '&y=' + m.y + '&button=' + button;
                sendWSMsg (msg);
            });

            // helper to paste string into HamClock
            function pasteString(str) {
                if (!str) return;
                for (let i = 0; i < str.length; i++) {
                    sendKey(str[i]);
                }
            }
            window.pasteString = pasteString;

            // suppress the browser's native right-click context menu on the canvas so a right-click
            // reaches pointerup above (as an 'other button' tap) instead of popping the OS/browser menu
            cvs.addEventListener ('contextmenu', function(event) {
                event.preventDefault();
            });


            // pointermove: send set_mouse
            cvs.addEventListener ('pointermove', function(event) {
                // all ours
                event.preventDefault();

                // cancel long press if pointer moves beyond jitter
                const m = getAppCoords (event);
                if (longpress_timer !== null && m) {
                    if (Math.abs(m.x-pointerdown_x) > MOUSE_JITTER || Math.abs(m.y-pointerdown_y) > MOUSE_JITTER)
                        cancelLongPress();
                }

                // not crazy fast
                let now = Date.now();
                if (pointermove_ms + UPDATE_MS > now)
                    return;
                pointermove_ms = now;

                if (!m) {
                    console.log("pointermove: don't know app_scale yet");
                    return;
                }

                // compose and send
                let msg = 'set_mouse?x=' + m.x + '&y=' + m.y;
                sendWSMsg (msg);
            });

            document.addEventListener('paste', e => {
                let str = e.clipboardData.getData('text/plain');
                pasteString(str);
            });


            // grab virtual cursor element
            vcursor_el = document.getElementById('virtual-cursor');

            // all set. start things off with the full image, repeats from then on with updates forever.
            getFullImage();

        }

    </script>

</head>

<body onload='onLoad()' bgcolor='black' >

    <!-- page is a single canvas, size will be set based on hamclock build size -->
    <canvas id='hamclock-cvs'></canvas>

    <!-- on-screen virtual pointer for remote control navigation -->
    <div id='virtual-cursor'>
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" style="position:absolute;top:0;left:0;" xmlns="http://www.w3.org/2000/svg">
            <polygon points="1,1 1,23 6.8,17.2 12,27 15.5,25 10.3,15.5 18,15.5" fill="#000000"/>
            <polygon points="2,3 2,20.5 6.5,16 11.2,24.8 13.5,23.5 8.8,14.8 15.5,14.8" fill="#FFFFFF"/>
        </svg>
    </div>

    <!-- in-page overlay for embedded links (e.g. ADS-B badge), toggled by showEmbed()/hideEmbed() -->
    <div id='embed-overlay'>
        <div id='embed-header'>
            <span id='embed-title'></span>
            <button id='embed-open-btn' onclick='embedOpenNewTab()'>Open in new tab &#8599;</button>
            <button id='embed-close-btn' onclick='hideEmbed()'>&#10005; Close</button>
        </div>
        <div id='embed-fallback-note'>
            Taking a while to load? This site may not allow embedding -- try "Open in new tab" above.
        </div>
        <iframe id='embed-frame'></iframe>
    </div>

</body>
</html> 

)_raw_html_";

#endif
