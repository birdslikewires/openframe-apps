/* manage the On The Air activation Panes for any "On the Air" organization.
 * server collects using fetchONTA.pl.
 *
 * We actually keep two lists:
 *   onta_spots: the complete raw list, not sorted; length in n_ontaspots, simple hash to detect change.
 *   ontawl_spots: watchlist-filterd and sorted for display; length in onta_ss.n_data
 */

#include "HamClock.h"

#include <unordered_map>
#include <unordered_set>
#include <string>


// config
static const char onta_page[] = "/ONTA/onta.txt";       // query page
static const char onta_file[] = "onta.txt";             // local cache file
#define ONTA_COLOR      RGB565(150,250,255)             // title and spot text color

// second source, same onta.txt line schema, generated server-side by gen_iota.pl from the
// Spothole API's sig=IOTA filter (see gen_iota.pl for why IOTA needs its own feed: it has no
// dedicated per-org spotting API of its own like POTA/SOTA/WWFF, only spots whose comments
// happened to mention an IOTA reference). Purely additive -- kept as a separate file so
// onta.txt itself and its other consumers are completely undisturbed. Same {file,page,interval}
// shape as onta_page/onta_file above, just read into the very same onta_spots array.
static const char onta_iota_page[] = "/ONTA/iota_spots.txt";
static const char onta_iota_file[] = "iota_spots.txt";

// third source, same idea again: gen_xonta.pl covers whatever "extra" xOTA programs Spothole
// has live beyond POTA/SOTA/WWFF/IOTA -- currently GMA, LLOTA and WWTOTA, see gen_xonta.pl's
// own header comment for why that specific set and not the many others Spothole's README
// mentions. Same purely-additive, separate-file treatment as iota_spots.txt above.
static const char onta_xonta_page[] = "/ONTA/xonta_spots.txt";
static const char onta_xonta_file[] = "xonta_spots.txt";

// each entry is one onta.txt-schema source to merge into onta_spots
typedef struct {
    const char *file;
    const char *page;
} ONTASource;
static const ONTASource onta_sources[] = {
    { onta_file, onta_page },
    { onta_iota_file, onta_iota_page },
    { onta_xonta_file, onta_xonta_page },
};
#define N_ONTASOURCES NARRAY(onta_sources)

// per-org marker color, filter bit, and abbreviation -- single source of truth, used by
// the marker-color lookup below, the org filter checkbox menu (runONTAOrgMenu), and the
// pane subtitle's abbreviated label when the full '+'-joined name list won't fit.
// Colors chosen to avoid RA8875_RED (watchlist highlight) and to stay visually distinct
// from each other; deliberately does NOT need to match the DX Cluster pane's own
// WCA/ARLHS/etc marker colors from spots.cpp -- different pane, different (non-overlapping)
// set of orgs, no reason they need to share a palette.
// Abbrev is NOT simply the first letter: WWFF/WWTOTA/WWBOTA all start with 'W', so a naive
// first-letter scheme collides three ways. Each org gets an explicit, disambiguated short
// code instead -- if you add a new org here, pick an abbrev that's unique against every
// existing one, not just its own first letter.
typedef struct {
    const char *org;
    uint16_t color;
    uint32_t bit;                // ONTA_ORGMASK_ALL below must be the OR of every bit here
    const char *abbrev;
} ONTAOrgInfo;
static const ONTAOrgInfo onta_org_info[] = {
    { "POTA",   RGB565(60,200,90)   , (1U<<0), "P"  },   // green
    { "SOTA",   RGB565(255,150,30)  , (1U<<1), "S"  },   // orange
    { "WWFF",   RGB565(0,190,160)   , (1U<<2), "WF" },   // teal
    { "IOTA",   RGB565(150,250,255) , (1U<<3), "I"  },   // cyan -- matches ONTA_COLOR
    { "GMA",    RGB565(150,150,170) , (1U<<4), "G"  },   // slate grey
    { "LLOTA",  RGB565(90,90,220)   , (1U<<5), "L"  },   // indigo
    { "WWTOTA", RGB565(184,115,51)  , (1U<<6), "WT" },   // copper
    { "TOWERS", RGB565(230,190,40)  , (1U<<7), "T"  },   // gold/amber
    { "WWBOTA", RGB565(140,148,60)  , (1U<<8), "WB" },   // olive/khaki
};
#define N_ONTAORGINFO NARRAY(onta_org_info)

// OR of every bit above -- this exact value means "every known org selected", which is
// treated as equivalent to no filtering at all (isSpotOrgOk() just passes everything once
// every bit it could ever test against is set, no special-casing needed). N.B. must be kept
// in sync by hand if a row above is added/removed -- there's no compile-time way to derive
// this from the array's own bit fields.
#define ONTA_ORGMASK_ALL ((1U<<0)|(1U<<1)|(1U<<2)|(1U<<3)|(1U<<4)|(1U<<5)|(1U<<6)|(1U<<7)|(1U<<8))

/* look up the marker color for an org name (spot.rx_grid, repurposed -- see header comment);
 * returns RA8875_BLACK as a "no specific color" sentinel for anything not in the table above,
 * eg an org the server side starts emitting that this client hasn't been taught about yet --
 * falls back to plain, uncolored text rather than misbehaving.
 */
static uint16_t ontaOrgMarkerColor (const char *org)
{
    if (org)
        for (const ONTAOrgInfo &oi : onta_org_info)
            if (!strcasecmp (oi.org, org))
                return (oi.color);
    return (RA8875_BLACK);
}

/* look up the filter bit for an org name; returns 0 (matches nothing) if unknown.
 */
static uint32_t ontaOrgBit (const char *org)
{
    if (org)
        for (const ONTAOrgInfo &oi : onta_org_info)
            if (!strcasecmp (oi.org, org))
                return (oi.bit);
    return (0);
}

// park/summit reference -> 2-letter state/province, purely additive side file. this
// data is essentially static (park locations don't move), so it's cached far longer
// than the spots feed itself and a missing/stale/absent file is never fatal -- the
// display just falls back to the 2-letter country code already embedded in every
// reference's own prefix (eg "US" from "US-2389").
static const char onta_parks_page[] = "/ONTA/onta_parks.txt";
static const char onta_parks_file[] = "onta_parks.txt";
#define ONTA_PARKS_INTERVAL ONTA_INTERVAL                    // refresh interval, secs
static std::unordered_map<std::string, std::string> onta_park_states;

// which activations the op has personally (re)spotted this session -- keyed by
// activator+reference (not tied to a specific frequency/mode/time, matching how a
// person would think of it: "have I already spotted this operator at this park").
// deliberately in-memory only: never written to NVRAM or any file, so it always
// starts empty on a fresh run and just reflects what happened since the app started.
static std::unordered_set<std::string> onta_spotted_by_me;

static std::string ontaSpottedKey (const DXSpot &s)
{
    return std::string(s.tx_call) + "|" + s.rx_call;          // rx_call repurposed: reference
}

static bool ontaWasSpottedByMe (const DXSpot &s)
{
    return onta_spotted_by_me.count (ontaSpottedKey(s)) != 0;
}

static void ontaMarkSpottedByMe (const DXSpot &s)
{
    onta_spotted_by_me.insert (ontaSpottedKey(s));
}


// names and functions for each sort type

/* qsort-style compare for ONTA's Band sort: ascending frequency (lowest to highest).
 * N.B. this incidentally groups spots by band too, since band frequency ranges don't
 * overlap -- deliberately separate from spots.cpp's qsDXCFreq (descending) so changing
 * ONTA's order doesn't also affect the ADIF logbook's own Band sort.
 */
static int qsONTABand (const void *v1, const void *v2)
{
    DXSpot *s1 = (DXSpot *)v1;
    DXSpot *s2 = (DXSpot *)v2;
    return (roundf(s1->kHz - s2->kHz));
}

/* qsort-style compare for ONTA's Org sort: group by org (spot.rx_grid, repurposed --
 * see header comment) ascending, then ascending frequency (lowest to highest) within
 * each org group.
 */
static int qsONTAOrg (const void *v1, const void *v2)
{
    DXSpot *s1 = (DXSpot *)v1;
    DXSpot *s2 = (DXSpot *)v2;
    int c = strcasecmp (s1->rx_grid, s2->rx_grid);
    if (c != 0)
        return (c);
    return (roundf(s1->kHz - s2->kHz));
}

typedef enum {
    ONTAS_BAND, 
    ONTAS_CALL,
    ONTAS_ORG,
    ONTAS_AGE,
    ONTAS_N,
} ONTASort;

typedef struct {
    const char *menu_name;                              // menu name for this sort
    PQSF qsf;                                           // matching qsort compare func
} ONTASortInfo;
static const ONTASortInfo onta_sorts[ONTAS_N] = {
    {"Band", qsONTABand},
    {"Call", qsDXCTXCall},
    {"Org",  qsONTAOrg},
    {"Age",  qsDXCSpotted},
};

// organization filter: one bit per known org (see ONTAOrgInfo/ONTA_ORGMASK_ALL above).
// ONTA_ORGMASK_ALL means "everything", same as the old empty-string "All" convention, but
// unlike the old free-text NV_ONTAORG field (limited to NV_ONTAORG_LEN=30 bytes -- a
// '+'-joined list of every known org's full name already exceeds that), a bitmask has no
// such ceiling no matter how many orgs get added later.
static uint32_t onta_orgmask;


// ages
static const uint8_t onta_ages[] = {10, 20, 40, 60};    // possible ages, minutes
static uint8_t onta_age;                                // one of above, once set
#define N_ONTAAGES NARRAY(onta_ages)                    // handy count


// mode filter: independent checkboxes, "at least 1" enforced by the menu itself.
// PHONE is a convenience shortcut meaning "SSB or FM or AM", not a distinct mode
// string of its own -- unlike the other 5 boxes it never appears in spot.mode.
#define ONTAMB_CW       (1<<0)
#define ONTAMB_FM       (1<<1)
#define ONTAMB_FT8      (1<<2)
#define ONTAMB_SSB      (1<<3)
#define ONTAMB_PHONE    (1<<4)
#define ONTAMB_DATA     (1<<5)
#define ONTAMB_ALL      (ONTAMB_CW|ONTAMB_FM|ONTAMB_FT8|ONTAMB_SSB|ONTAMB_PHONE|ONTAMB_DATA)
static uint8_t onta_modes;                              // bitmask of ONTAMB_*

// band filter: same bitmask convention as Live Spots' psk_bands, but only 8 of the 12
// supported bands get their own checkbox -- matching what POTA.app's own spot filter
// dropdown offers (40/20/30/17/15/12/10/6). Everything else (160/80/60/2m, or any
// frequency outside a known ham band at all) is covered by a single "Other" checkbox
// instead, using a dedicated bit well outside HamBandSetting's 0..11 range.
static uint32_t onta_bands;                             // bit i set means HamBandSetting i shown
#define TST_ONTABAND(b) ((b) != HAMBAND_NONE && (onta_bands & (1U<<(b))) != 0)
#define SET_ONTABAND(b) (onta_bands |= (1U<<(b)))
#define ONTA_BAND_OTHER (1U<<31)                                // catch-all bit
#define ONTA_NBANDS_SHOWN 8                                     // how many get their own checkbox
static const HamBandSetting onta_shown_bands[ONTA_NBANDS_SHOWN] = {
    HAMBAND_40M, HAMBAND_20M, HAMBAND_30M, HAMBAND_17M,
    HAMBAND_15M, HAMBAND_12M, HAMBAND_10M, HAMBAND_6M,
};


// state
static DXSpot *onta_spots;                              // malloced list, complete
static int n_ontaspots;                                 // n spots in onta_spots
static DXSpot *ontawl_spots;                            // filtered malloced list, count in onta_ss.n_data
static ScrollState onta_ss;                             // scrolling state
static uint8_t onta_sortby;                             // one of ONTASort
static bool onta_showbio;                               // whether click shows bio
static bool onta_showstate = true;                           // whether rows show state/country; else callsign gets the room
static uint32_t spots_hash;                             // hash of onta_spots as last fully loaded
static uint32_t onta_loaded_sig;                        // content signature of source files when last fully loaded
static uint32_t onta_peek_sig;                          // latest signature seen while refresh is deferred
#define NEW_SPOTS()     (onta_peek_sig != onta_loaded_sig)  // handy test for new spots pending

/* return a simple hash of the given spots array
 */
static uint32_t spotsHash (const DXSpot *spots, int n_spots)
{
    // https://stackoverflow.com/questions/1579721/why-are-5381-and-33-so-important-in-the-djb2-algorithm
    uint8_t *bytes = (uint8_t *) spots;
    uint32_t hash = 5381;
    for (uint8_t *bytes_end = bytes + n_spots * sizeof(DXSpot); bytes < bytes_end; bytes++)
        hash = (hash << 5) + hash + *bytes;            // hash*33 + c
    return (hash);
}

/* return whether the given spot's org is allowed
 */
static bool isSpotOrgOk (const DXSpot &s)
{
    // remember: rx_grid is repurposed for program name

    // ONTA_ORGMASK_ALL passes everything, including an org this client doesn't recognize
    // (unlike the old string filter, an unrecognized org can't accidentally get excluded
    // by a stale/incomplete filter list -- ontaOrgBit() returning 0 for an unknown org
    // would otherwise silently hide it forever even under "All")
    if (onta_orgmask == ONTA_ORGMASK_ALL)
        return (true);

    return ((onta_orgmask & ontaOrgBit (s.rx_grid)) != 0);
}


/* return whether the given spot passes the current mode+band filter.
 * a blank mode or a frequency outside any known ham band always passes -- we don't
 * hide a spot just because we can't classify it.
 */
static bool ontaModeBandOk (const DXSpot &s)
{
    // band -- one of the 8 bands with their own checkbox, or everything else (160/80/60/2m,
    // or any frequency outside a known ham band entirely) bucketed under "Other"
    HamBandSetting b = findHamBand (s.kHz);
    bool is_shown_band = false;
    for (int i = 0; i < ONTA_NBANDS_SHOWN && !is_shown_band; i++)
        if (b == onta_shown_bands[i])
            is_shown_band = true;
    if (is_shown_band) {
        if (!TST_ONTABAND(b))
            return (false);
    } else {
        if (!(onta_bands & ONTA_BAND_OTHER))
            return (false);
    }

    // mode -- note a blank mode is deliberately NOT auto-passed here; it falls through
    // to the "data" catch-all below so it's actually filterable (previously it bypassed
    // the filter entirely, which is why spots with missing mode data could appear under
    // every single mode checkbox regardless of what was actually checked)
    bool cw  = strcasecmp (s.mode, "CW")  == 0;
    bool ft8 = strcasecmp (s.mode, "FT8") == 0;
    bool ssb = strcasecmp (s.mode, "SSB") == 0 || strcasecmp (s.mode, "USB") == 0
                                                || strcasecmp (s.mode, "LSB") == 0;
    bool fm  = strcasecmp (s.mode, "FM")  == 0;
    bool am  = strcasecmp (s.mode, "AM")  == 0;
    bool data = !cw && !ft8 && !ssb && !fm && !am;         // catch-all: blank, FT4, RTTY, etc

    if (cw   && (onta_modes & ONTAMB_CW))    return (true);
    if (ft8  && (onta_modes & ONTAMB_FT8))   return (true);
    if (ssb  && (onta_modes & ONTAMB_SSB))   return (true);
    if (fm   && (onta_modes & ONTAMB_FM))    return (true);
    if (data && (onta_modes & ONTAMB_DATA))  return (true);
    if ((ssb || fm || am) && (onta_modes & ONTAMB_PHONE)) return (true);   // shortcut

    return (false);
}

/* fill counts[N_ONTAORGINFO] with how many currently-fetched spots would be visible for
 * each org if it alone were checked -- respects every filter EXCEPT org itself: age, mode,
 * band, AND watch list Only/Not (mirrors rebuildONTAWatchList()'s own pipeline exactly,
 * just skipping its isSpotOrgOk() step since here we're bucketing BY org instead of
 * filtering by a fixed one). This choice -- counting watch-list-filtered spots too -- means
 * a count here always matches what would actually appear in the list if that box alone were
 * checked. If that's ever undesired (eg someone forgets a narrow watch list is active and
 * wonders why counts look low), drop the checkWatchListSpot() check below; nothing else
 * needs to change.
 *
 * also fills *modeband_filtered with whether mode or band filtering is currently narrower
 * than "everything" -- used by runONTAOrgMenu() to append "(filtered)" to its header so a
 * low count isn't ambiguous between "quiet right now" and "hidden by your mode/band
 * filter". Age is deliberately NOT part of that signal: it's always some finite window,
 * never "everything", so flagging it the same way would be true 100% of the time.
 */
static void ontaOrgCounts (uint32_t counts[], bool *modeband_filtered)
{
    memset (counts, 0, N_ONTAORGINFO * sizeof(counts[0]));

    time_t oldest = myNow() - 60*onta_age;
    for (int i = 0; i < n_ontaspots; i++) {
        DXSpot &spot = onta_spots[i];
        if (spot.spotted < oldest)
            continue;
        if (!ontaModeBandOk (spot))
            continue;
        if (checkWatchListSpot (WLID_ONTA, spot) == WLS_NO)
            continue;
        uint32_t bit = ontaOrgBit (spot.rx_grid);
        for (size_t j = 0; j < N_ONTAORGINFO; j++)
            if (onta_org_info[j].bit == bit) {
                counts[j]++;
                break;
            }
    }

    if (modeband_filtered) {
        uint32_t all_bands = ONTA_BAND_OTHER;
        for (int i = 0; i < ONTA_NBANDS_SHOWN; i++)
            all_bands |= (1U << onta_shown_bands[i]);
        *modeband_filtered = (onta_modes != ONTAMB_ALL) || (onta_bands != all_bands);
    }
}


/* insure our settings are loaded
 */
static void loadONTASettings (void)
{
    if (!NVReadUInt8 (NV_ONTASORTBY, &onta_sortby) || onta_sortby >= ONTAS_N) {
        onta_sortby = ONTAS_AGE;
        NVWriteUInt8 (NV_ONTASORTBY, onta_sortby);
    }
    if (!NVReadUInt32 (NV_ONTA_ORGMASK, &onta_orgmask)) {
        onta_orgmask = ONTA_ORGMASK_ALL;
        NVWriteUInt32 (NV_ONTA_ORGMASK, onta_orgmask);
    }
    // NV_ONTAORG (the old free-text org filter) is retired in favor of the bitmask above --
    // clear it explicitly so a stale value from an older build doesn't linger unused. Its
    // NVRAM slot is deliberately kept, not removed, to avoid shifting every other NV_Name's
    // storage index.
    NVWriteString (NV_ONTAORG, "");
    if (!NVReadUInt8 (NV_ONTA_MAXAGE, &onta_age)) {
        onta_age = onta_ages[1];
        NVWriteUInt8 (NV_ONTA_MAXAGE, onta_age);
    }
    if (!NVReadUInt8 (NV_ONTA_MODES, &onta_modes)) {
        onta_modes = ONTAMB_ALL;
        NVWriteUInt8 (NV_ONTA_MODES, onta_modes);
    }
    if (!NVReadUInt32 (NV_ONTA_BANDS, &onta_bands)) {
        onta_bands = ONTA_BAND_OTHER;
        for (int i = 0; i < ONTA_NBANDS_SHOWN; i++)
            SET_ONTABAND(onta_shown_bands[i]);
        NVWriteUInt32 (NV_ONTA_BANDS, onta_bands);
    }

    uint8_t showst;
    if (!NVReadUInt8 (NV_ONTA_SHOWSTATE, &showst)) {
        showst = 1;                                     // as before this setting existed
        NVWriteUInt8 (NV_ONTA_SHOWSTATE, showst);
    }
    onta_showstate = (showst != 0);

    // determine onta_showbio
    uint8_t bio = 0;
    if (getQRZId() != QRZ_NONE) {
        if (!NVReadUInt8 (NV_ONTABIO, &bio))
            bio = 0;
    }
    onta_showbio = (bio != 0);
}

/* save our settings
 */
static void saveONTASettings (void)
{
    NVWriteUInt8 (NV_ONTASORTBY, onta_sortby);
    NVWriteUInt32 (NV_ONTA_ORGMASK, onta_orgmask);
    NVWriteUInt8 (NV_ONTA_MAXAGE, onta_age);
    NVWriteUInt8 (NV_ONTABIO, onta_showbio);
    NVWriteUInt8 (NV_ONTA_MODES, onta_modes);
    NVWriteUInt32 (NV_ONTA_BANDS, onta_bands);
    NVWriteUInt8 (NV_ONTA_SHOWSTATE, onta_showstate);
}

/* fill out[3] with the 2-letter state/province for the given reference if we have
 * one cached (from onta_parks.txt), else fall back to the 2-letter country code
 * parsed directly out of the reference's own prefix (eg "US" from "US-2389", "DE"
 * from a German reference) -- that prefix is always there regardless of whether
 * the state lookup ever loads, so this always has *something* useful to show.
 */
static void ontaStateOrCountry (const char *ref, char out[3])
{
    auto it = onta_park_states.find (ref);
    if (it != onta_park_states.end() && it->second.length() >= 2) {
        out[0] = it->second[0];
        out[1] = it->second[1];
    } else {
        const char *dash = strchr (ref, '-');
        size_t n = dash ? (size_t)(dash - ref) : strlen(ref);
        out[0] = n >= 1 ? ref[0] : '?';
        out[1] = n >= 2 ? ref[1] : '?';
    }
    out[2] = '\0';
}

// ontheair row layout, in characters -- shared between formatONTASpot() (drawing)
// and checkOnTheAirTouch() (tap-the-callsign-for-full-text) so the two can't drift
// out of sync. FAST_FONT is fixed-width at ONTA_CHAR_W pixels/char, same constant
// drawONTAVisSpots() already uses for the frequency field's background box.
#define ONTA_CHAR_W       6
#define ONTA_P0_FREQ_LEN  5
#define ONTA_P0_CALL_LEN  3
#define ONTA_P0_ID_LEN    9
#define ONTA_PX_FREQ_LEN  6
#define ONTA_PX_CALL_LEN  5
#define ONTA_PX_ID_LEN    9
#define ONTA_P0_CALL_NOST_LEN  5                // call len when state column is hidden: gets its 2 chars
#define ONTA_PX_CALL_NOST_LEN  8                // call len when state column is hidden: gets its 2 chars + 1 blank

/* return number of chars for the callsign field, wider when the state column is hidden
 */
static int ontaCallLen (const SBox &box)
{
    if (BOX_IS_PANE_0(box))
        return (onta_showstate ? ONTA_P0_CALL_LEN : ONTA_P0_CALL_NOST_LEN);
    else
        return (onta_showstate ? ONTA_PX_CALL_LEN : ONTA_PX_CALL_NOST_LEN);
}

/* create a line of text for the given spot that fits within the box known to be for PANE_0 or PANE_123.
 * pass back n chars assigned to frequency.
 */
static void formatONTASpot (const DXSpot &spot, const SBox &box, char *line, size_t l_len, int &freq_len)
{
    const char *id = spot.rx_call;                      // repurposed
    int age = myNow() - spot.spotted;                   // seconds old

    // state/country column, empty when hidden -- its room then goes to the callsign instead
    char st[3] = "";
    if (onta_showstate)
        ontaStateOrCountry (id, st);

    int call_len = ontaCallLen (box);

    if (BOX_IS_PANE_0(box)) {

        // box is 22 wide: freq(5) call(3) " " id(9) " " state(2) age(1)
        // callsign is the field trimmed to make room for state/country (park
        // reference kept full-length); tap directly on the callsign to see it
        // in full via a tooltip, see checkOnTheAirTouch(). With state hidden
        // the callsign is 5 instead, ie, freq(5) call(5) " " id(9) " " age(1)

        freq_len     = ONTA_P0_FREQ_LEN;
        int id_len   = ONTA_P0_ID_LEN;

        // 5 chars for freq requires MHz when > 99999
        size_t ns;
        if (spot.kHz > 99999) {
            ns = snprintf (line, l_len, "%4.0fM%*.*s %*.*s %s",
                    spot.kHz * 1e-3,
                    call_len, call_len, spot.tx_call,
                    id_len, id_len, id,
                    st);
        } else {
            ns = snprintf (line, l_len, "%*.0f%*.*s %*.*s %s",
                    freq_len, spot.kHz,
                    call_len, call_len, spot.tx_call,
                    id_len, id_len, id,
                    st);
        }
        formatAge (age, line+ns, l_len-ns, 1);

    } else {

        // box is 26 wide: freq(6) call(5) " " id(9) " " state(2) " " age(1)
        // same trade-off as above; with state hidden the callsign is 8 instead,
        // ie, freq(6) call(8) " " id(9) " " age(1)

        freq_len     = ONTA_PX_FREQ_LEN;
        int id_len   = ONTA_PX_ID_LEN;

        size_t ns;
        if (onta_showstate)
            ns = snprintf (line, l_len, "%*.0f%*.*s %*.*s %2.2s ",
                    freq_len, spot.kHz,
                    call_len, call_len, spot.tx_call,
                    id_len, id_len, id,
                    st);
        else
            ns = snprintf (line, l_len, "%*.0f%*.*s %*.*s ",
                    freq_len, spot.kHz,
                    call_len, call_len, spot.tx_call,
                    id_len, id_len, id);

        formatAge (age, line+ns, l_len-ns, 1);
    }
}

// generous size for a '+'-joined list of every known org's FULL name -- unlike the old
// NV_ONTAORG_LEN (30, sized for the persisted string), this is purely a local display
// buffer size with no NVRAM ceiling to respect, so there's no risk of the overflow that
// motivated moving persistence to a bitmask in the first place.
#define ONTA_ORGLABEL_LEN 100

/* fill f[] (of size f_len) with the currently effective org filter label: either "All", or
 * a '+'-joined list of every currently-selected org's FULL name (eg "POTA+SOTA"). Full names
 * always, regardless of available screen width -- callers needing a width-constrained version
 * for compact display should call ontaOrgLabelAbbrev() instead, which falls back to each
 * org's short abbrev (eg "P+S") only when the full-name version won't fit.
 * shared by drawONTAPane (subtitle) and drawONTAVisSpots (empty-results message) so
 * the two never drift out of sync.
 */
static void ontaOrgLabel (char *f, size_t f_len)
{
    if (onta_orgmask == ONTA_ORGMASK_ALL) {
        quietStrncpy (f, "All", f_len);
        return;
    }

    size_t off = 0;
    bool first = true;
    for (const ONTAOrgInfo &oi : onta_org_info) {
        if (!(onta_orgmask & oi.bit))
            continue;
        int n = snprintf (f+off, off < f_len ? f_len-off : 0, "%s%s", first ? "" : "+", oi.org);
        if (n > 0)
            off += (size_t)n;
        first = false;
    }
    if (off == 0)
        quietStrncpy (f, "All", f_len);     // defensive: shouldn't happen, the org menu
                                              // enforces at least 1 checked -- treat an
                                              // empty result as All rather than blank
}

/* like ontaOrgLabel() but using each org's short abbrev (eg "P+S+G+L") instead of its full
 * name, for callers that need to fit within a limited pixel width. Still returns "All"
 * unabbreviated when every org is selected, since that already fits comfortably everywhere
 * it's used.
 */
static void ontaOrgLabelAbbrev (char *f, size_t f_len)
{
    if (onta_orgmask == ONTA_ORGMASK_ALL) {
        quietStrncpy (f, "All", f_len);
        return;
    }

    size_t off = 0;
    bool first = true;
    for (const ONTAOrgInfo &oi : onta_org_info) {
        if (!(onta_orgmask & oi.bit))
            continue;
        int n = snprintf (f+off, off < f_len ? f_len-off : 0, "%s%s", first ? "" : "+", oi.abbrev);
        if (n > 0)
            off += (size_t)n;
        first = false;
    }
    if (off == 0)
        quietStrncpy (f, "All", f_len);
}

/* print a short message centered in the *listing* portion of an ONTA-style pane, ie below
 * the title/subtitle. deliberately does NOT call prepPlotBox() like plotMessage() does --
 * that would erase the title/subtitle and draw an unwanted inner border. the listing area
 * is assumed to already be freshly cleared to black by the caller.
 */
static void drawONTAEmptyMsg (const SBox &box, const char *message)
{
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    tft.setTextColor (RA8875_WHITE);

    char *msg_cpy = strdup (message);
    size_t msg_len = strlen (message);
    uint16_t msg_printed = 0;
    uint16_t y = box.y + LISTING_Y0 + 2*LISTING_DY;

    for (int n_lines = 0; n_lines < 4 && msg_printed < msg_len; n_lines++) {

        // chop at max width -- maxStringW overwrites all beyond with 0's
        size_t l_before = strlen (msg_cpy);
        (void) maxStringW (msg_cpy, box.w-4);
        size_t l_after = strlen (msg_cpy);

        // unless finished, look for a closer blank so we don't break mid-word
        if (l_after < l_before) {
            char *blank = strrchr (msg_cpy, ' ');
            if (blank)
                blank[1] = '\0';
        }

        uint16_t msgw = getTextWidth (msg_cpy);
        tft.setCursor (box.x + (box.w-msgw)/2, y);
        tft.print (msg_cpy);

        msg_printed += strlen (msg_cpy);
        strcpy (msg_cpy, message+msg_printed+(message[msg_printed] == ' ' ? 1 : 0));
        y += 2*LISTING_DY;
    }

    free (msg_cpy);
}

/* redraw all visible ontawl_spots in the given pane box.
 * N.B. this just draws the ontawl_spots, use drawONTAPane to start from scratch.
 */
static void drawONTAVisSpots (const SBox &box)
{
    // can't quite use drawVisibleSpots() because of unique formatting :-(

    // update ADIF in case our WL uses it
    freshenADIFFile();

    // init and reset to black
    uint16_t x = box.x + 1;
    uint16_t y0 = box.y + LISTING_Y0;
    tft.fillRect (box.x+1, y0-LISTING_OS, box.w-2, box.h - (LISTING_Y0-LISTING_OS+1), RA8875_BLACK);
    selectFontStyle (LIGHT_FONT, FAST_FONT);

    // show vis spots and note if any would be red above and below
    bool any_older = false;
    bool any_newer = false;
    int min_i, max_i;
    if (onta_ss.getVisDataIndices (min_i, max_i) > 0) {
        for (int i = 0; i < onta_ss.n_data; i++) {
            const DXSpot &spot = ontawl_spots[i];
            if (i < min_i) {
                if (!any_older)
                    any_older = checkWatchListSpot (WLID_ONTA, spot) == WLS_HILITE;
            } else if (i > max_i) {
                if (!any_newer)
                    any_newer = checkWatchListSpot (WLID_ONTA, spot) == WLS_HILITE;
            } else {
                // build info line
                char line[50];
                int freq_len;
                formatONTASpot (spot, box, line, sizeof(line), freq_len);

                // set y location
                uint16_t y = y0 + onta_ss.getDisplayRow(i) * LISTING_DY;

                // highlight overall bg if on watch list
                if (checkWatchListSpot (WLID_ONTA, spot) == WLS_HILITE)
                    tft.fillRect (x, y-LISTING_OS, box.w-2, LISTING_DY-2, RA8875_RED);

                // show freq with proper band map color background
                uint16_t bg_col = getBandColor (spot.kHz);
                uint16_t txt_col = getGoodTextColor (bg_col);
                tft.setTextColor(txt_col);
                tft.fillRect (x, y-LISTING_OS, freq_len*6, LISTING_DY-2, bg_col);
                tft.setCursor (x, y);
                tft.printf ("%*.*s", freq_len, freq_len, line);

                // show remainder of line in white, or green + struck through once we've
                // personally (re)spotted this activation this session -- except the id (park/
                // summit/etc reference) field, which gets its own org-colored background the
                // same way freq gets a band-colored one above, see ontaOrgMarkerColor(). that
                // field's text color follows the background for contrast, same as freq's does,
                // regardless of spotted state -- consistent with how freq's own text color
                // already ignores spotted state.
                bool spotted = ontaWasSpottedByMe (spot);
                uint16_t rem_color = spotted ? RA8875_GREEN : RA8875_WHITE;
                int call_len = ontaCallLen (box);
                int id_len   = BOX_IS_PANE_0(box) ? ONTA_P0_ID_LEN   : ONTA_PX_ID_LEN;

                // call field + 1 trailing blank, plain
                uint16_t call_x = x + freq_len*ONTA_CHAR_W;
                tft.setTextColor (rem_color);
                tft.setCursor (call_x, y);
                tft.printf ("%.*s", call_len+1, line+freq_len);

                // id field, org-colored background
                uint16_t id_x = call_x + (call_len+1)*ONTA_CHAR_W;
                uint16_t id_col = ontaOrgMarkerColor (spot.rx_grid);          // repurposed: program name
                if (id_col != RA8875_BLACK) {
                    tft.fillRect (id_x, y-LISTING_OS, id_len*ONTA_CHAR_W, LISTING_DY-2, id_col);
                    tft.setTextColor (getGoodTextColor (id_col));
                } else
                    tft.setTextColor (rem_color);
                tft.setCursor (id_x, y);
                tft.printf ("%.*s", id_len, line+freq_len+call_len+1);

                // remainder: blank(s) + state/country + age, plain
                uint16_t tail_x = id_x + id_len*ONTA_CHAR_W;
                tft.setTextColor (rem_color);
                tft.setCursor (tail_x, y);
                tft.printf (line+freq_len+call_len+1+id_len);

                if (spotted) {
                    uint16_t rem_x0 = call_x;
                    uint16_t rem_w = getTextWidth (line+freq_len);
                    tft.drawLine (rem_x0, y+3, rem_x0+rem_w, y+3, RA8875_GREEN);
                }
            }
        }
    } else {
        // nothing to show -- if a specific org is selected (not the "All" pool, which
        // realistically always has something), say so rather than leave the pane blank.
        // POTA is unlikely to ever hit this, but SOTA/WWFF/IOTA can go quiet for a while.
        char f[ONTA_ORGLABEL_LEN];
        ontaOrgLabel (f, sizeof(f));
        if (strcmp (f, "All")) {
            char msg[ONTA_ORGLABEL_LEN+50];
            snprintf (msg, sizeof(msg), "No '%s' org spots found - watch here for more", f);
            drawONTAEmptyMsg (box, msg);
        }
    }

    // scroll controls red if any more red spots in their directions
    uint16_t up_color = ONTA_COLOR;
    uint16_t dw_color = ONTA_COLOR;
    if (onta_ss.okToScrollDown() &&
                ((scrollTopToBottom() && any_older) || (!scrollTopToBottom() && any_newer)))
        dw_color = RA8875_RED;
    if (onta_ss.okToScrollUp() &&
                ((scrollTopToBottom() && any_newer) || (!scrollTopToBottom() && any_older)))
        up_color = RA8875_RED;

    onta_ss.drawScrollUpControl (box, up_color, ONTA_COLOR);
    onta_ss.drawScrollDownControl (box, dw_color, ONTA_COLOR);
}

// dropdown arrow geometry for the org-picker affordance in the subtitle row -- small,
// scaled down from menu.cpp's own down-pointing-triangle "submenu" indicator (MENU_IS=6)
// to fit this compact row. onta_orgarrow_b is the tap hit region (padded a little larger
// than the visual glyph itself, a bigger target than the drawn triangle), set fresh each
// time drawONTAPane runs and consumed by checkOnTheAirTouch. N.B. exact pixel placement
// here is a best-effort estimate -- untested on real hardware/SDL, may want minor on-device
// tuning of the offsets below once actually seen on screen.
#define ONTA_ORGARROW_W     7
#define ONTA_ORGARROW_H     5
#define ONTA_ORGARROW_GAP   3
static SBox onta_orgarrow_b;

/* draw spots in the given pane box from scratch.
 * use drawONTAVisSpots() if want to redraw just the spots.
 */
static void drawONTAPane (const SBox &box)
{
    // prep
    prepPlotBox (box);

    // title
    const char *title = BOX_IS_PANE_0(box) ? "On Air" : "On The Air";
    selectFontStyle (LIGHT_FONT, SMALL_FONT);
    tft.setTextColor(ONTA_COLOR);
    uint16_t pw = getTextWidth(title);
    tft.setCursor (box.x + (box.w-pw)/2, box.y + PANETITLE_H);
    tft.print (title);

    // show current org filter -- "All", the full '+'-joined org names if they fit, else
    // each org's short abbrev instead (eg "P+S+G+L") -- with a small dropdown arrow next to
    // it that opens runONTAOrgMenu() (see checkOnTheAirTouch for the matching hit-test
    // against onta_orgarrow_b, set below)
    char f[ONTA_ORGLABEL_LEN];
    ontaOrgLabel (f, sizeof(f));
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    uint16_t avail_w = box.w >= 2 ? box.w-2 : 0;
    uint16_t arrow_room = ONTA_ORGARROW_GAP + ONTA_ORGARROW_W;
    uint16_t f_l = getTextWidth (f);
    if (f_l + arrow_room > avail_w) {
        // full names (+ arrow) don't fit -- try the abbreviated form instead
        ontaOrgLabelAbbrev (f, sizeof(f));
        f_l = getTextWidth (f);
    }
    // last-resort truncation -- same safety net the old code always relied on, in case even
    // the abbreviated form is still too wide (eg an extremely narrow pane)
    if (f_l + arrow_room > avail_w)
        f_l = maxStringW (f, avail_w > arrow_room ? avail_w-arrow_room : 0);
    tft.setTextColor(RA8875_WHITE);
    uint16_t f_x = box.x + (box.w - (f_l+arrow_room))/2;
    uint16_t f_y = box.y + SUBTITLE_Y0;
    tft.setCursor (f_x, f_y);
    tft.print (f);

    // dropdown arrow immediately to the right of the label -- same down-pointing-triangle
    // visual language as the "submenu" indicator in menu.cpp, scaled down for this row
    uint16_t ax0 = f_x + f_l + ONTA_ORGARROW_GAP;
    uint16_t ay0 = f_y + 2;                              // nudge down toward text center
    onta_orgarrow_b.x = ax0;
    onta_orgarrow_b.y = ay0 >= 2 ? ay0-2 : 0;             // pad tap target a bit above...
    onta_orgarrow_b.w = ONTA_ORGARROW_W + 3;              // ...right...
    onta_orgarrow_b.h = ONTA_ORGARROW_H + 6;              // ...and below the visual glyph
    uint16_t tx0 = ax0,                     ty0 = ay0;
    uint16_t tx1 = ax0 + ONTA_ORGARROW_W,   ty1 = ay0;
    uint16_t tx2 = ax0 + ONTA_ORGARROW_W/2, ty2 = ay0 + ONTA_ORGARROW_H;
    tft.fillTriangle (tx0, ty0, tx1, ty1, tx2, ty2, RA8875_WHITE);

    // show each spot
    drawONTAVisSpots (box);
}

/* ONTA's "home" view, ie, where the list sits when freshly (re)built and nothing has been scrolled.
 * For the Age sort that is the newest spot (end of the array). For Band/Call/Org it is the
 * BEGINNING of the array (see rebuildONTAWatchList()). ScrollState::atNewest() only knows about
 * the end of the array, so using it for the non-Age sorts meant that paging down to the last
 * page looked like "back at newest", which triggered a full rebuild that snapped the view
 * back to the first page. These two helpers keep "at home" and "scroll to home" consistent
 * with each other for every sort order.
 */
static void ontaScrollToHome (void)
{
    if (onta_sortby == ONTAS_AGE)
        onta_ss.scrollToNewest();
    else
        onta_ss.scrollToOldest();
}

static bool ontaAtHome (void)
{
    if (onta_sortby == ONTAS_AGE)
        return (onta_ss.atNewest());

    // same clamping as ScrollState::scrollToOldest()
    int home = onta_ss.max_vis - 1;
    if (home > onta_ss.n_data - 1)
        home = onta_ss.n_data - 1;
    if (home < 0)
        home = 0;
    return (onta_ss.top_vis == home);
}

/* handy check whether New Spot symbol needs changing on/off
 */
static void checkONTANewSpotSymbol (bool was_at_home)
{
    if (was_at_home && !ontaAtHome()) {
        // hold rotation while scrolled away. refreshing is deferred meanwhile, see updateOnTheAir()
        onta_peek_sig = onta_loaded_sig;                // nothing new yet as of now
        ROTHOLD_SET(PLOT_CH_ONTA);
    } else if (!was_at_home && ontaAtHome()) {
        // fresh view from the beginning and release rotation hold
        scheduleNewPlot (PLOT_CH_ONTA);
        ROTHOLD_CLR(PLOT_CH_ONTA);
    }
}


/* scroll up, if appropriate to do so now.
 */
static void scrollONTAUp (const SBox &box)
{
    bool was_at_home = ontaAtHome();
    if (onta_ss.okToScrollUp ()) {
        onta_ss.scrollUp ();
        drawONTAVisSpots (box);
    }
    checkONTANewSpotSymbol (was_at_home);
}

/* scroll down, if appropriate to do so now.
 */
static void scrollONTADown (const SBox &box)
{
    bool was_at_home = ontaAtHome();
    if (onta_ss.okToScrollDown()) {
        onta_ss.scrollDown ();
        drawONTAVisSpots (box);
    }
    checkONTANewSpotSymbol (was_at_home);
}

/* set bio, radio and new DX from given spot
 */
static void engageONTARow (DXSpot &s)
{
    if (onta_showbio)
        openQRZBio (s);
    setRadioSpot(s.kHz);
    newDX (s.tx_ll, NULL, s.tx_call);
}

/* percent-encode s as one query-string value into buf (buf_len must be at least
 * 3*strlen(s)+1). mirrors the encoder already used for the pane's "search the web"
 * feature, just factored out here since this file has its own outbound query to build.
 */
static void ontaURLEncode (const char *s, char *buf, size_t buf_len)
{
    size_t used = 0;
    for (const unsigned char *p = (const unsigned char *)s; *p && used+4 < buf_len; p++) {
        char c = (char)*p;
        if (c == ' ')
            buf[used++] = '+';
        else if (isalnum((unsigned char)c) || c=='-' || c=='_' || c=='.' || c=='~')
            buf[used++] = c;
        else
            used += snprintf (buf+used, buf_len-used, "%%%02X", (unsigned char)c);
    }
    buf[used < buf_len ? used : buf_len-1] = '\0';
}

/* post (or re-post) a spot for the given ONTA activation to the OHB backend, which relays
 * it on to whichever network (POTA etc) the spot came from. the spotter is always our own
 * configured callsign and the reporting software is always identified as HamClock -- op has
 * no say over either, same as Hunterlog and similar tools always identify themselves.
 * return whether accepted, with a short reason in ynot either way.
 */
static bool postONTASpot (const DXSpot &s, const char *comment, Message &ynot)
{
    WiFiClient onta_client;
    bool ok = false;

    // encode each dynamic field separately -- reference codes in particular often
    // contain '/' (eg SOTA "W7A/AN-011") which is not safe unencoded in a query value
    char e_org[3*MAX_SPOTGRID_LEN+4], e_call[3*MAX_SPOTCALL_LEN+4], e_ref[3*MAX_SPOTCALL_LEN+4];
    char e_mode[3*MAX_SPOTMODE_LEN+4], e_spotter[3*NV_CALLSIGN_LEN+4], e_comment[3*60+4];
    ontaURLEncode (s.rx_grid, e_org, sizeof(e_org));                    // repurposed: program name
    ontaURLEncode (s.tx_call, e_call, sizeof(e_call));
    ontaURLEncode (s.rx_call, e_ref, sizeof(e_ref));                    // repurposed: reference id
    ontaURLEncode (s.mode[0] ? s.mode : "", e_mode, sizeof(e_mode));
    ontaURLEncode (getCallsign(), e_spotter, sizeof(e_spotter));
    ontaURLEncode (comment ? comment : "", e_comment, sizeof(e_comment));

    char page[600];
    snprintf (page, sizeof(page),
        "/ONTA/spot.pl?org=%s&call=%s&ref=%s&khz=%.1f&mode=%s&spotter=%s&source=HamClock&comment=%s",
        e_org, e_call, e_ref, s.kHz, e_mode, e_spotter, e_comment);

    if (onta_client.connect (backend_host, backend_port)) {

        updateClocks(false);

        Serial.printf ("ONTA: %s\n", page);
        httpHCGET (onta_client, backend_host, page);

        // check the HTTP status line ourselves before trying to parse a body -- a missing
        // or misconfigured spot.pl (404, 500 etc) would otherwise just look like a garbled,
        // confusing response instead of the clear, specific problem it actually is
        char status_line[100];
        int code = 0;
        if (!getTCPLine (onta_client, status_line, sizeof(status_line), NULL)) {
            ynot.set ("Spot timeout");
        } else if (sscanf (status_line, "HTTP/%*s %d", &code) != 1 || code == 0) {
            ynot.set ("Unexpected reply");
        } else if (code == 404) {
            ynot.set ("spot.pl not found");
        } else if (code != 200) {
            char buf[100];
            snprintf (buf, sizeof(buf), "Backend error %d", code);
            ynot.set (buf);
        } else if (!httpSkipHeader (onta_client)) {
            ynot.set ("Spot timeout");
        } else {
            char line[100];
            while (getTCPLine (onta_client, line, sizeof(line), NULL)) {
                if (strncmp (line, "error=", 6) == 0) {
                    ynot.set (line+6);
                    ok = false;
                    break;
                }
                if (strncmp (line, "ok=", 3) == 0)
                    ok = true;
            }
            if (!ok && ynot.get()[0] == '\0')
                ynot.set ("No reply");
        }

        onta_client.stop();

    } else {
        ynot.set ("Connection failed");
    }

    return (ok);
}

/* show a small popup letting the op (re)spot the given ONTA activation, a la Hunterlog.
 * spotter is always our configured callsign; reporting software is always "HamClock".
 */
static void runONTASpotMenu (const SBox &box, const DXSpot &s)
{
    // read-only info lines -- kept short so the menu never needs to grow wider than
    // this (narrow) pane; a wider menu spills past the pane's own bounds and its
    // backing-store restore can't fully clean up the strip left outside the pane
    char line1[50], line2[50], line3[50];
    if (s.mode[0])
        snprintf (line1, sizeof(line1), "%s %.0f %s", s.tx_call, s.kHz, s.mode);
    else
        snprintf (line1, sizeof(line1), "%s %.0f", s.tx_call, s.kHz);
    snprintf (line2, sizeof(line2), "%s %s", s.rx_grid, s.rx_call);        // program + reference
    snprintf (line3, sizeof(line3), "Spotter: %s", getCallsign());

    // hard guarantee regardless of how long a callsign/reference/comment happens to be --
    // measure in the same font runMenu() will actually draw these labels in
    selectFontStyle (LIGHT_FONT, FAST_FONT);
    uint16_t safe_w = box.w > 40 ? box.w - 40 : box.w;    // leaves room for indent/selector/margin
    maxStringW (line1, safe_w);
    maxStringW (line2, safe_w);
    maxStringW (line3, safe_w);

    // editable comment field, starts blank
    MenuText cm_mt;
    memset (&cm_mt, 0, sizeof(cm_mt));
    char comment[60];
    comment[0] = '\0';
    cm_mt.text = comment;
    cm_mt.t_mem = sizeof(comment);
    static char cm_label[] = "Comment: ";
    cm_mt.label = cm_label;
    cm_mt.l_mem = sizeof(cm_label);
    cm_mt.c_pos = cm_mt.w_pos = 0;
    cm_mt.to_upper = false;

    MenuItem mitems[] = {
        {MENU_LABEL, false, 0, 2, "Spot?",   NULL},                         // 0
        {MENU_LABEL, false, 0, 2, line1,                       NULL},         // 1
        {MENU_LABEL, false, 0, 2, line2,                       NULL},         // 2
        {MENU_LABEL, false, 0, 2, line3,                       NULL},         // 3
        {MENU_TEXT,  false, 0, 2, cm_mt.label,                 &cm_mt},       // 4
    };
    #define ONTASPOTMENU_N NARRAY(mitems)

    SBox menu_b = box;                          // copy, not ref!
    menu_b.x = box.x + 5;
    menu_b.y = box.y + SUBTITLE_Y0;
    menu_b.w = box.w - 10;
    SBox ok_b;
    MenuInfo menu = {menu_b, ok_b, UF_CLOCKSOK, M_CANCELOK, 1, ONTASPOTMENU_N, mitems};
    if (runMenu (menu)) {
        menuMsg (menu_b, RA8875_WHITE, "spotting...");
        Message ynot;
        if (postONTASpot (s, comment, ynot)) {
            ontaMarkSpottedByMe (s);
            menuMsg (menu_b, RA8875_GREEN, "spot sent");
        } else {
            // menuMsg() just centers and prints -- it doesn't wrap or clip -- so clamp
            // the message ourselves. it may include text relayed verbatim from spot.pl
            // or POTA's own HTTP reason phrase, which we don't control the length of.
            char errbuf[100];
            quietStrncpy (errbuf, ynot.get(), sizeof(errbuf));
            selectFontStyle (LIGHT_FONT, FAST_FONT);
            maxStringW (errbuf, menu_b.w > 10 ? menu_b.w - 10 : menu_b.w);
            menuMsg (menu_b, RA8875_RED, errbuf);
        }
    }

    // belt and suspenders: force a full, guaranteed-clean repaint of the whole pane
    // regardless of Ok/Cancel, rather than trusting the menu system's own backing-store
    // restore to have perfectly undone every pixel it touched
    drawONTAPane (box);
}

/* rebuild ontawl_spots from onta_spots
 */
static void rebuildONTAWatchList(void)
{
    // update ADIF in case our WL uses it
    freshenADIFFile();

    // extract qualifying spots from onta_spots into ontawl_spots
    time_t oldest = myNow() - 60*onta_age;               // minutes to seconds
    onta_ss.n_data = 0;                                  // reset count, don't bother to resize ontawl_spots
    int n_old = 0, n_no_org = 0, n_no_modeband = 0, n_no_wl = 0;
    for (int i = 0; i < n_ontaspots; i++) {
        DXSpot &spot = onta_spots[i];
        if (spot.spotted < oldest)
            n_old++;
        else if (!isSpotOrgOk (spot))
            n_no_org++;
        else if (!ontaModeBandOk (spot))
            n_no_modeband++;
        else if (checkWatchListSpot (WLID_ONTA, spot) == WLS_NO)
            n_no_wl++;
        else {
            // ok!
            ontawl_spots = (DXSpot *) realloc (ontawl_spots, (onta_ss.n_data+1) * sizeof(DXSpot));
            if (!ontawl_spots)
                fatalError ("No mem for %d watch list spots", onta_ss.n_data+1);
            ontawl_spots[onta_ss.n_data++] = spot;
        }
    }

    Serial.printf ("ONTA: %d total - %d too-old - %d not-org - %d not-mode/band - %d not-WL = %d showing\n",
                    n_ontaspots, n_old, n_no_org, n_no_modeband, n_no_wl, onta_ss.n_data);

    // sort as desired
    qsort (ontawl_spots, onta_ss.n_data, sizeof(DXSpot), onta_sorts[onta_sortby].qsf);

    // Age is the one genuinely chronological sort, so "catch up to the newest spot" is the
    // sensible initial view there. Band/Call/Org are ascending, non-chronological orderings
    // (eg 14094 before 14300) -- for those, start the view at the beginning of the array
    // (lowest frequency, first call/org alphabetically). ontaScrollToHome() does the right one
    // for the current sort, and ontaAtHome() recognizes the same position afterwards.
    ontaScrollToHome();
}


/* show menu to let op select sort and edit watch list
 * Age:
 *   ( ) 10 m   ( ) 40 m
 *   ( ) 20 m   ( ) 60 m
 * Sort by:
 *   ( ) Age    ( ) Call
 *   ( ) Band   ( ) Org
 * Watch:
 *
 * N.B. Org filtering now has its own dedicated popup (runONTAOrgMenu(), opened by tapping
 * the small dropdown arrow next to the subtitle in drawONTAPane()) rather than living here
 * as a free-text field -- see onta_orgmask/ONTAOrgInfo for why.
 */
static void runONTASortMenu (const SBox &box)
{
    // insure defaults are set in case retrieval failed
    loadONTASettings();

    // set up the watch list MENU_TEXT field
    MenuText wl_mt;                                             // menu text prompt context
    char wl_state[WLA_MAXLEN];                                  // wl state, menu may change
    setupWLMenuText (WLID_ONTA, wl_mt, wl_state);               // N.B. we must free wl_mt.text

    // set up a second, purely decorative MENU_TEXT whose only job is printing a static
    // "Watching:" header on its own full-width row directly above wl_mt's. Has to be a
    // MENU_TEXT (not a MENU_LABEL grid item) because MENU_TEXT rows get their own dedicated
    // row below the checkbox grid without affecting n_table/n_tblrows at all (see
    // runMenu()'s layout math in menu.cpp) -- a MENU_LABEL grid item changes n_table, which
    // changes n_tblrows via ceil(n_table/n_cols), which reflows every single checkbox's
    // column/row position, since the grid above was hand-tuned assuming an exact n_tblrows
    // value (confirmed broken/scrambled on real hardware -- do not go back to a MENU_LABEL
    // here). No label_fp/text_fp registered, and its .text is never read after runMenu()
    // returns -- completely inert, nothing to save or validate.
    MenuText watching_mt;
    memset (&watching_mt, 0, sizeof(watching_mt));
    char watching_label[] = "Watching:";
    watching_mt.label = watching_label;
    watching_mt.l_mem = sizeof(watching_label);
    char watching_text[] = "";                                  // unused, never read back
    watching_mt.text = watching_text;
    watching_mt.t_mem = sizeof(watching_text);

    // build the possible age labels
    char onta_ages_str[N_ONTAAGES][10];
    for (int i = 0; i < N_ONTAAGES; i++)
        snprintf (onta_ages_str[i], sizeof(onta_ages_str[i]), "%d m", onta_ages[i]);

    // whether to show bio on click, only show in menu at all if bio source has been set in Setup
    bool show_bio_enabled = getQRZId() != QRZ_NONE;
    MenuFieldType bio_lbl_mft = show_bio_enabled ? MENU_LABEL : MENU_IGNORE;
    MenuFieldType bio_yes_mft = show_bio_enabled ? MENU_1OFN : MENU_IGNORE;
    MenuFieldType bio_no_mft = show_bio_enabled ? MENU_1OFN : MENU_IGNORE;

    // narrow layout needs BLANK, not IGNORE, for hidden bio -- see comment above the
    // narrow mitems array for why
    MenuFieldType bio_lbl_mft_n = show_bio_enabled ? MENU_LABEL : MENU_BLANK;
    MenuFieldType bio_yes_mft_n = show_bio_enabled ? MENU_1OFN : MENU_BLANK;
    MenuFieldType bio_no_mft_n  = show_bio_enabled ? MENU_1OFN : MENU_BLANK;

    // narrow "Data Pane" view (PANE_0) can't fit 3 columns -- use 2, more vertical, instead
    bool narrow = BOX_IS_PANE_0(box);

    SBox menu_b = box;                          // copy, not ref!
    menu_b.y = box.y + 7;
    if (!narrow && show_bio_enabled) {
        // one row height (MENU_RH in menu.cpp, not exported) -- 3-col layout is one row
        // taller with Bio shown (its row isn't removed the way it is when Bio is off) --
        // shift up to compensate so it doesn't overlap the pane.
        // N.B. menu_b.y is unsigned: for a pane docked at the very top of the screen
        // (box.y == 0, eg PANE_1/2/3), box.y+7 can be less than this 11px shift, so guard
        // against underflow (which previously wrapped y to ~65535 and made runMenu()'s own
        // off-screen repositioning logic shove the whole menu down to the bottom of the
        // screen instead of over the pane -- the reported "menu opens at the bottom" bug).
        if (menu_b.y >= 11)
            menu_b.y -= 11;
        else
            menu_b.y = 0;
    }
    if (narrow) {
        // 2-col layout has plenty of slack (~104px content in a 139px pane) -- a small
        // inset stays comfortably clear of the map without risking any auto-widen
        menu_b.x = box.x + 5;
        menu_b.w = box.w - 10;
    } else {
        // 3-col layout's content is tighter than box.w-10 would allow; full width avoids
        // runMenu's own auto-widen growing the box off-center to the right
        menu_b.x = box.x;
        menu_b.w = box.w;
    }
    SBox ok_b;
    bool ok;

    if (narrow) {

        MenuItem mitems[] = {
            // column 1: Age/Sort first so they always start at the top row regardless of
            // whether Bio is shown; Bio (or blank padding if hidden) moved to the bottom
            {MENU_LABEL, false,                       0, 2,  "Age:", NULL},                         // 0
            {MENU_1OFN, onta_ages[0] == onta_age,     2, 12, onta_ages_str[0], NULL},               // 1
            {MENU_1OFN, onta_ages[1] == onta_age,     2, 12, onta_ages_str[1], NULL},               // 2
            {MENU_1OFN, onta_ages[2] == onta_age,     2, 12, onta_ages_str[2], NULL},               // 3
            {MENU_1OFN, onta_ages[3] == onta_age,     2, 12, onta_ages_str[3], NULL},               // 4
            {MENU_LABEL, false,                       0, 2,  "Sort:", NULL},                        // 5
            {MENU_1OFN, onta_sortby == ONTAS_AGE,     3, 12, onta_sorts[ONTAS_AGE].menu_name, NULL},// 6
            {MENU_1OFN, onta_sortby == ONTAS_BAND,    3, 12, onta_sorts[ONTAS_BAND].menu_name,NULL},// 7
            {MENU_1OFN, onta_sortby == ONTAS_CALL,    3, 12, onta_sorts[ONTAS_CALL].menu_name,NULL},// 8
            {MENU_1OFN, onta_sortby == ONTAS_ORG,     3, 12, onta_sorts[ONTAS_ORG].menu_name, NULL},// 9
            {bio_lbl_mft_n, false,                    0, 2,  "Bio:", NULL},                         // 10
            {bio_yes_mft_n, onta_showbio,              1, 12, "Yes", NULL},                          // 11
            {bio_no_mft_n, !onta_showbio,              1, 12, "No", NULL},                           // 12
            {MENU_BLANK, false,                       0, 2,  NULL, NULL},                           // 13
            {MENU_BLANK, false,                       0, 2,  NULL, NULL},                           // 14
            {MENU_BLANK, false,                       0, 2,  NULL, NULL},                           // 15
            {MENU_BLANK, false,                       0, 2,  NULL, NULL},                           // 16

            // column 2: modes then bands, each with its own header label, stacked vertically
            {MENU_LABEL, false,                       0, 2,  "Modes:", NULL},                       // 17
            {MENU_AL1OFN, (onta_modes&ONTAMB_CW)!=0,  6, 2,  "CW",  NULL},                          // 18
            {MENU_AL1OFN, (onta_modes&ONTAMB_FM)!=0,  6, 2,  "FM",  NULL},                          // 19
            {MENU_AL1OFN, (onta_modes&ONTAMB_FT8)!=0, 6, 2,  "FT8", NULL},                          // 20
            {MENU_AL1OFN, (onta_modes&ONTAMB_SSB)!=0, 6, 2,  "SSB", NULL},                          // 21
            {MENU_AL1OFN, (onta_modes&ONTAMB_PHONE)!=0,6,2,  "PHONE", NULL},                        // 22
            {MENU_AL1OFN, (onta_modes&ONTAMB_DATA)!=0, 6, 2, "DATA",  NULL},                        // 23
            {MENU_LABEL, false,                       0, 2,  "Bands:", NULL},                       // 24
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_40M),  7, 12, findBandName(HAMBAND_40M),  NULL},     // 25
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_20M),  7, 12, findBandName(HAMBAND_20M),  NULL},     // 26
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_30M),  7, 12, findBandName(HAMBAND_30M),  NULL},     // 27
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_17M),  7, 12, findBandName(HAMBAND_17M),  NULL},     // 28
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_15M),  7, 12, findBandName(HAMBAND_15M),  NULL},     // 29
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_12M),  7, 12, findBandName(HAMBAND_12M),  NULL},     // 30
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_10M),  7, 12, findBandName(HAMBAND_10M),  NULL},     // 31
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_6M),   7, 12, findBandName(HAMBAND_6M),   NULL},     // 32
            {MENU_AL1OFN, (onta_bands&ONTA_BAND_OTHER)!=0, 7, 12, "Other", NULL},                   // 33

            // text fields across the bottom -- watching_mt is a second, inert MENU_TEXT purely
            // to print a static "Watching:" header on its own full-width row just above wl_mt's
            // (see watching_mt's setup above and the big comment there for why this has to be a
            // second MENU_TEXT rather than a MENU_LABEL grid item)
            {MENU_TEXT, false,                        0, 2, watching_mt.label, &watching_mt},       // 34
            {MENU_TEXT, false,                        5, 2, wl_mt.label, &wl_mt},                   // 35
        };
        #define ONTAMENU_NARROW_N   NARRAY(mitems)

        MenuInfo menu = {menu_b, ok_b, UF_CLOCKSOK, M_CANCELOK, 2, ONTAMENU_NARROW_N, mitems};
        menu.no_parent = true;          // indent here is layout only, see MenuInfo.no_parent
        ok = runMenu (menu);
        if (ok) {
            onta_showbio = mitems[11].set;

            if (mitems[1].set)       onta_age = onta_ages[0];
            else if (mitems[2].set)  onta_age = onta_ages[1];
            else if (mitems[3].set)  onta_age = onta_ages[2];
            else if (mitems[4].set)  onta_age = onta_ages[3];
            else fatalError ("runONTASortMenu no age set (narrow)");

            if (mitems[6].set)       onta_sortby = ONTAS_AGE;
            else if (mitems[7].set)  onta_sortby = ONTAS_BAND;
            else if (mitems[8].set)  onta_sortby = ONTAS_CALL;
            else if (mitems[9].set)  onta_sortby = ONTAS_ORG;
            else fatalError ("runONTASortMenu no sort set (narrow)");

            onta_modes = 0;
            if (mitems[18].set) onta_modes |= ONTAMB_CW;
            if (mitems[19].set) onta_modes |= ONTAMB_FM;
            if (mitems[20].set) onta_modes |= ONTAMB_FT8;
            if (mitems[21].set) onta_modes |= ONTAMB_SSB;
            if (mitems[22].set) onta_modes |= ONTAMB_PHONE;
            if (mitems[23].set) onta_modes |= ONTAMB_DATA;

            onta_bands = 0;
            if (mitems[25].set) SET_ONTABAND(HAMBAND_40M);
            if (mitems[26].set) SET_ONTABAND(HAMBAND_20M);
            if (mitems[27].set) SET_ONTABAND(HAMBAND_30M);
            if (mitems[28].set) SET_ONTABAND(HAMBAND_17M);
            if (mitems[29].set) SET_ONTABAND(HAMBAND_15M);
            if (mitems[30].set) SET_ONTABAND(HAMBAND_12M);
            if (mitems[31].set) SET_ONTABAND(HAMBAND_10M);
            if (mitems[32].set) SET_ONTABAND(HAMBAND_6M);
            if (mitems[33].set) onta_bands |= ONTA_BAND_OTHER;
        }

    } else {

        MenuItem mitems[] = {
            // column 1
            {bio_lbl_mft, false,                      0, 2, "Bio:", NULL},                          // 0
            {MENU_LABEL, false,                       0, 2, "Age:", NULL},                          // 1
            {MENU_BLANK, false,                       0, 2, NULL, NULL},                            // 2
            {MENU_LABEL, false,                       0, 2, "Sort:", NULL},                         // 3
            {MENU_BLANK, false,                       0, 2, NULL, NULL},                            // 4
            {MENU_AL1OFN, (onta_modes&ONTAMB_CW)!=0,  6, 2,  "CW",  NULL},                          // 5
            {MENU_AL1OFN, (onta_modes&ONTAMB_FM)!=0,  6, 2,  "FM",  NULL},                          // 6
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_40M),  7, 12, findBandName(HAMBAND_40M),  NULL},     // 7
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_20M),  7, 12, findBandName(HAMBAND_20M),  NULL},     // 8
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_30M),  7, 12, findBandName(HAMBAND_30M),  NULL},     // 9

            // column 2
            {bio_yes_mft, onta_showbio,               1, 2, "Yes", NULL},                           // 10
            {MENU_1OFN, onta_ages[0] == onta_age,     2, 2, onta_ages_str[0], NULL},                // 11
            {MENU_1OFN, onta_ages[2] == onta_age,     2, 2, onta_ages_str[2], NULL},                // 12
            {MENU_1OFN, onta_sortby == ONTAS_AGE,     3, 2, onta_sorts[ONTAS_AGE].menu_name, NULL}, // 13
            {MENU_1OFN, onta_sortby == ONTAS_BAND,    3, 2, onta_sorts[ONTAS_BAND].menu_name,NULL}, // 14
            {MENU_AL1OFN, (onta_modes&ONTAMB_FT8)!=0, 6, 2,  "FT8", NULL},                          // 15
            {MENU_AL1OFN, (onta_modes&ONTAMB_SSB)!=0, 6, 2,  "SSB", NULL},                          // 16
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_17M),  7, 12, findBandName(HAMBAND_17M),  NULL},     // 17
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_15M),  7, 12, findBandName(HAMBAND_15M),  NULL},     // 18
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_12M),  7, 12, findBandName(HAMBAND_12M),  NULL},     // 19

            // columns 3
            {bio_no_mft, !onta_showbio,               1, 2, "No", NULL},                            // 20
            {MENU_1OFN, onta_ages[1] == onta_age,     2, 2, onta_ages_str[1], NULL},                // 21
            {MENU_1OFN, onta_ages[3] == onta_age,     2, 2, onta_ages_str[3], NULL},                // 22
            {MENU_1OFN, onta_sortby == ONTAS_CALL,    3, 2, onta_sorts[ONTAS_CALL].menu_name,NULL}, // 23
            {MENU_1OFN, onta_sortby == ONTAS_ORG,     3, 2, onta_sorts[ONTAS_ORG].menu_name, NULL}, // 24
            {MENU_AL1OFN, (onta_modes&ONTAMB_PHONE)!=0,6, 2, "PHONE", NULL},                        // 25
            {MENU_AL1OFN, (onta_modes&ONTAMB_DATA)!=0, 6, 2, "DATA",  NULL},                        // 26
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_10M),  7, 12, findBandName(HAMBAND_10M),  NULL},     // 27
            {MENU_AL1OFN, TST_ONTABAND(HAMBAND_6M),   7, 12, findBandName(HAMBAND_6M),   NULL},     // 28
            {MENU_AL1OFN, (onta_bands&ONTA_BAND_OTHER)!=0, 7, 12, "Other", NULL},                   // 29

            // text fields across the bottom -- see the matching narrow-layout comment above
            {MENU_TEXT, false,                        0, 2, watching_mt.label, &watching_mt},       // 30
            {MENU_TEXT, false,                        5, 2, wl_mt.label, &wl_mt},                   // 31
        };
        #define ONTAMENU_N   NARRAY(mitems)

        MenuInfo menu = {menu_b, ok_b, UF_CLOCKSOK, M_CANCELOK, 3, ONTAMENU_N, mitems};
        menu.no_parent = true;          // indent here is layout only, see MenuInfo.no_parent
        ok = runMenu (menu);
        if (ok) {
            onta_showbio = mitems[10].set;

            if (mitems[11].set)
                onta_age = onta_ages[0];
            else if (mitems[12].set)
                onta_age = onta_ages[2];
            else if (mitems[21].set)
                onta_age = onta_ages[1];
            else if (mitems[22].set)
                onta_age = onta_ages[3];
            else
                fatalError ("runONTASortMenu no age set");

            if (mitems[13].set)
                onta_sortby = ONTAS_AGE;
            else if (mitems[14].set)
                onta_sortby = ONTAS_BAND;
            else if (mitems[23].set)
                onta_sortby = ONTAS_CALL;
            else if (mitems[24].set)
                onta_sortby = ONTAS_ORG;
            else
                fatalError ("runONTASortMenu no sort set");

            onta_modes = 0;
            if (mitems[5].set)  onta_modes |= ONTAMB_CW;
            if (mitems[6].set)  onta_modes |= ONTAMB_FM;
            if (mitems[15].set) onta_modes |= ONTAMB_FT8;
            if (mitems[16].set) onta_modes |= ONTAMB_SSB;
            if (mitems[25].set) onta_modes |= ONTAMB_PHONE;
            if (mitems[26].set) onta_modes |= ONTAMB_DATA;

            onta_bands = 0;
            if (mitems[7].set)  SET_ONTABAND(HAMBAND_40M);
            if (mitems[8].set)  SET_ONTABAND(HAMBAND_20M);
            if (mitems[9].set)  SET_ONTABAND(HAMBAND_30M);
            if (mitems[17].set) SET_ONTABAND(HAMBAND_17M);
            if (mitems[18].set) SET_ONTABAND(HAMBAND_15M);
            if (mitems[19].set) SET_ONTABAND(HAMBAND_12M);
            if (mitems[27].set) SET_ONTABAND(HAMBAND_10M);
            if (mitems[28].set) SET_ONTABAND(HAMBAND_6M);
            if (mitems[29].set) onta_bands |= ONTA_BAND_OTHER;
        }
    }

    if (ok) {

        // must recompile to update wl but runMenu already insured wl compiles ok
        Message ynot;
        if (lookupWatchListState (wl_mt.label) != WLA_OFF && !compileWatchList (WLID_ONTA, wl_mt.text, ynot))
            fatalError ("onair failed recompling wl %s: %s", wl_mt.text, ynot.get());
        setWatchList (WLID_ONTA, wl_mt.label, wl_mt.text);
        Serial.printf ("ONTA: set WL to %s %s\n", wl_mt.label, wl_mt.text);

        // save
        saveONTASettings();

        // full refresh
        ontaScrollToHome();
        scheduleNewPlot (PLOT_CH_ONTA);
    }

    // always free the working text
    free (wl_mt.text);
}

/* show a small dedicated popup letting the op pick which org(s) to show, one checkbox per
 * known org (see ONTAOrgInfo), all checked by default (equivalent to "All"). Opened by
 * tapping the small dropdown arrow next to the org label in drawONTAPane's subtitle (see
 * onta_orgarrow_b / checkOnTheAirTouch) -- distinct from runONTASortMenu's combined
 * Age/Sort/Modes/Bands/Watch popup, which no longer includes Org at all.
 */
static void runONTAOrgMenu (const SBox &box)
{
    // insure defaults are set in case retrieval failed
    loadONTASettings();

    // per-org counts, respecting every filter except org itself -- see ontaOrgCounts()'s
    // own comment for exactly what that means and why
    uint32_t counts[N_ONTAORGINFO];
    bool modeband_filtered;
    ontaOrgCounts (counts, &modeband_filtered);

    SBox menu_b = box;                          // copy, not ref!
    menu_b.y = box.y + 2;                        // open near the top of the pane
    menu_b.x = box.x + 1;                        // nearly the full pane width: org labels + State? are tight
    menu_b.w = box.w - 2;
    SBox ok_b;

    // per-org labels need persistent (not stack-transient) storage for the duration of
    // runMenu() below, since MenuItem.label is just a pointer, not a copy
    char org_labels[N_ONTAORGINFO][24];

    // two columns, filled top to bottom: header + one row per org on the left, then the
    // "State?" checkbox on the first org's row in the right column, padded with blanks to the
    // same height so it lands there. The header is split across the two top cells -- "Show
    // orgs:" on the left, "(filtered)" (if applicable) on the right -- because runMenu() sizes
    // every column to the widest label, so one long header would make the whole 2-column
    // dialog about twice as wide as the pane. Each org label gets that org's own marker color as its
    // background, the same color its park/summit field has in the spot list, so the op can
    // see at a glance which listed rows each checkbox controls.
    #define ONTAORGMENU_COL     (1 + N_ONTAORGINFO)                 // items per column
    #define ONTAORGMENU_N       (2 * ONTAORGMENU_COL)
    MenuItem mitems[ONTAORGMENU_N];
    uint16_t label_bgs[ONTAORGMENU_N];
    memset (label_bgs, 0, sizeof(label_bgs));

    mitems[0] = {MENU_LABEL, false, 0, 2, "Show orgs:", NULL};
    for (size_t i = 0; i < N_ONTAORGINFO; i++) {
        snprintf (org_labels[i], sizeof(org_labels[i]), "%s (%u)",
                                                    onta_org_info[i].org, (unsigned)counts[i]);
        mitems[1+i] = {MENU_AL1OFN, (onta_orgmask & onta_org_info[i].bit) != 0, 1, 12,
                                                    org_labels[i], NULL, false};
        label_bgs[1+i] = onta_org_info[i].color;
    }
    #define ONTAORGMENU_STATE_I (ONTAORGMENU_COL + 1)
    for (size_t i = ONTAORGMENU_COL; i < ONTAORGMENU_N; i++)
        mitems[i] = {MENU_BLANK, false, 0, 0, NULL, NULL, false};
    if (modeband_filtered)
        mitems[ONTAORGMENU_COL] = {MENU_LABEL, false, 0, 2, "(filtered)", NULL, false};
    mitems[ONTAORGMENU_STATE_I] = {MENU_TOGGLE, onta_showstate, 2, 2, "State?", NULL, false};

    MenuInfo menu = {menu_b, ok_b, UF_CLOCKSOK, M_CANCELOK, 2, ONTAORGMENU_N, mitems};
    menu.no_parent = true;                      // indents are visual only, State? is not a child of anything
    menu.label_bgs = label_bgs;
    menu.fit_cols = true;                       // State? column only as wide as it needs, never overlaps long counts
    if (runMenu (menu)) {
        uint32_t new_mask = 0;
        for (size_t i = 0; i < N_ONTAORGINFO; i++)
            if (mitems[1+i].set)
                new_mask |= onta_org_info[i].bit;
        // MENU_AL1OFN guarantees at least 1 stays checked, but fall back to All defensively
        // rather than ever persist a mask that would hide every spot
        onta_orgmask = new_mask ? new_mask : ONTA_ORGMASK_ALL;
        onta_showstate = mitems[ONTAORGMENU_STATE_I].set;

        saveONTASettings();

        // full refresh, same as runONTASortMenu does on Ok
        ontaScrollToHome();
        scheduleNewPlot (PLOT_CH_ONTA);
    }
}

/* reset storage and prep for box
 */
static void resetONTAStorage (const SBox &box)
{
    free (onta_spots);
    onta_spots = NULL;
    n_ontaspots = 0;
    free (ontawl_spots);
    ontawl_spots = NULL;
    onta_ss.init ((box.h - LISTING_Y0)/LISTING_DY, 0, 0, onta_ss.DIR_FROMSETUP);
    onta_ss.scrollToNewest();
    onta_ss.initNewSpotsSymbol (box, ONTA_COLOR);
}

/* (re)load the park/summit reference -> 2-letter state/province lookup, if due.
 * cheap and safe to call every time retrieveONTA() runs: openCachedFile() enforces
 * ONTA_PARKS_INTERVAL itself, so this is a no-op download-wise most of the time,
 * and the file is small (only currently-active references) so re-parsing it each
 * call is negligible. a missing/failed/empty file is not an error -- it just means
 * onta_park_states stays empty and every row falls back to showing its country.
 */
static void retrieveONTAParks (void)
{
    FILE *fp = openCachedFile (onta_parks_file, onta_parks_page, ONTA_PARKS_INTERVAL, 0);
    if (!fp)
        return;

    onta_park_states.clear();

    char line[50];
    while (fgets (line, sizeof(line), fp)) {
        chompString (line);
        if (line[0] == '#' || line[0] == '\0')
            continue;
        char ref[20], state[8];                          // N.B. match sscanf fields
        if (sscanf (line, "%19[^,],%7s", ref, state) == 2)
            onta_park_states[ref] = state;
    }

    fclose (fp);

    Serial.printf ("ONTA: read %d park states\n", (int)onta_park_states.size());
}

/* download one onta.txt-schema source and append its spots onto the (already allocated,
 * possibly non-empty) onta_spots/n_ontaspots pair. return whether io ok, even if no data --
 * same "ok" semantics retrieveONTA() used to have for its single source.
 */
static bool retrieveONTASource (const ONTASource &src)
{
    FILE *fp = openCachedFile (src.file, src.page, ONTA_INTERVAL, 0);
    bool ok = false;

    if (fp) {

        // look alive
        updateClocks(false);

        // add each spot
        char line[100];
        while (fgets (line, sizeof(line), fp)) {

            // rm trailing \n
            chompString (line);

            // skip comments
            if (line[0] == '#')
                continue;

            // prep next spot but don't count until known good
            onta_spots = (DXSpot*) realloc (onta_spots, (n_ontaspots+1)*sizeof(DXSpot));
            if (!onta_spots)
                fatalError ("No room for %d ONTA spots", n_ontaspots+1);
            DXSpot &new_sp = onta_spots[n_ontaspots];
            new_sp = {};

            // parse
            char dxcall[20], dxgrid[20], mode[20], id[20], prog[20];    // N.B. match sscanf fields
            unsigned long hz, unx;
            float lat_d, lng_d;
            // JI1ORE,430510000,1728012018,CW,QM05,35.7566,140.189,JA-1234,SOTA
            if (sscanf (line, "%19[^,],%lu,%lu,%19[^,],%19[^,],%f,%f,%19[^,],%19s",
                                dxcall, &hz, &unx, mode, dxgrid, &lat_d, &lng_d, id, prog) != 9) {

                // maybe a blank mode?
                if (sscanf (line, "%19[^,],%lu,%lu,,%19[^,],%f,%f,%19[^,],%19s",
                                dxcall, &hz, &unx, dxgrid, &lat_d, &lng_d, id, prog) != 8) {
                    // .. nope, something else
                    Serial.printf ("ONTA: bogus %s\n", line);
                    continue;
                }

                // .. yup that was it
                mode[0] = '\0';
            }

            // ignore long calls
            if (strlen (dxcall) >= MAX_SPOTCALL_LEN) {
                Serial.printf ("ONTA: ignoring long call: %s\n", line);
                continue;
            }

            // check valid freq
            float kHz = hz * 1e-3F;
            if (findHamBand (kHz) == HAMBAND_NONE) {
                Serial.printf ("ONTA: ignoring freq: %s\n", line);
                continue;
            }

            // DXCC
            if (!call2DXCC (dxcall, new_sp.tx_dxcc)) {
                Serial.printf ("ONTA: no DXCC for %s\n", dxcall);
                continue;
            }

            // fill new_sp, repurpose rx_call for id and rx_grid for program name
            quietStrncpy (new_sp.tx_call, dxcall, sizeof(new_sp.tx_call));
            quietStrncpy (new_sp.tx_grid, dxgrid, sizeof(new_sp.tx_grid));
            quietStrncpy (new_sp.rx_call, id, sizeof(new_sp.rx_call));
            quietStrncpy (new_sp.rx_grid, prog, sizeof(new_sp.rx_grid));
            quietStrncpy (new_sp.mode, mode, sizeof(new_sp.mode));
            new_sp.rx_ll = de_ll;                      // us?
            new_sp.tx_ll.lat_d = lat_d;
            new_sp.tx_ll.lng_d = lng_d;
            new_sp.tx_ll.normalize();
            new_sp.kHz = kHz;
            new_sp.spotted = unx;

            // ok! append to spots[]
            n_ontaspots += 1;
        }

        // io ok, even if none found
        ok = true;
        fclose (fp);
    }

    // done
    Serial.printf ("ONTA: %s: read %d spots so far\n", src.file, n_ontaspots);

    // result
    return (ok);
}

/* return a cheap signature of the current content of every ONTA source file, without parsing
 * anything or touching onta_spots. used to notice that new data has arrived while a refresh is
 * being deferred because the op has scrolled away from the home view. openCachedFile() still
 * enforces ONTA_INTERVAL so this only downloads when a fetch is actually due.
 */
static uint32_t ontaSourcesSig (void)
{
    uint32_t hash = 5381;
    for (size_t i = 0; i < N_ONTASOURCES; i++) {
        FILE *fp = openCachedFile (onta_sources[i].file, onta_sources[i].page, ONTA_INTERVAL, 0);
        if (!fp)
            continue;
        unsigned char buf[512];
        size_t n;
        while ((n = fread (buf, 1, sizeof(buf), fp)) > 0)
            for (size_t j = 0; j < n; j++)
                hash = (hash << 5) + hash + buf[j];
        fclose (fp);
    }
    return (hash);
}

/* download all spots from every onta.txt-schema source (onta.txt itself, plus IOTA's
 * separate iota_spots.txt) into the one onta_spots array.
 * return whether io ok, even if no data -- true so long as at least one source loaded ok,
 * so eg a transient hiccup fetching iota_spots.txt doesn't blank out real POTA/SOTA/WWFF data.
 */
static bool retrieveONTA (void)
{
    // reset
    free (onta_spots);
    onta_spots = NULL;
    n_ontaspots = 0;

    bool any_ok = false;
    for (size_t i = 0; i < N_ONTASOURCES; i++)
        if (retrieveONTASource (onta_sources[i]))
            any_ok = true;

    Serial.printf ("ONTA: read %d total spots from %d source(s)\n", n_ontaspots, (int)N_ONTASOURCES);

    // refresh the park->state lookup too -- independent of the outcome above
    retrieveONTAParks();

    // note what we just loaded so a later deferred check can tell if anything newer has arrived
    onta_loaded_sig = onta_peek_sig = ontaSourcesSig();

    // result
    return (any_ok);
}

/* called occsionally to draw ONTA pane in box.
 * return whether io ok.
 */
bool updateOnTheAir (const SBox &box, bool fresh)
{
    // init all if new
    if (fresh) {
        ROTHOLD_CLR(PLOT_CH_ONTA);
        resetONTAStorage (box);
        loadONTASettings();
    }

    // if scrolled away from home, defer the full download/parse/rebuild so the list under the op's
    // finger neither blocks nor changes. just check cheaply for newer data and light the "New"
    // symbol if there is some; tapping New scrolls home and schedules a normal full refresh through
    // here, which re-applies every filter via rebuildONTAWatchList().
    if (!fresh && !ontaAtHome()) {
        onta_peek_sig = ontaSourcesSig();
        onta_ss.drawNewSpotsSymbol (NEW_SPOTS(), false);
        ROTHOLD_SET(PLOT_CH_ONTA);
        return (true);
    }

    uint32_t prev_hash = spots_hash;
    bool ok = retrieveONTA();
    if (ok) {
        spots_hash = spotsHash (onta_spots, n_ontaspots);
        if (ontaAtHome()) {
            // N.B. org rotation retired -- see isONTARotating()'s comment -- checkbox
            // multi-select via onta_orgmask always shows the full union of checked orgs
            // now, so there's no longer a "next org" to advance to here.
            rebuildONTAWatchList();
            onta_ss.drawNewSpotsSymbol (false, false);                  // New symbol off
            ROTHOLD_CLR(PLOT_CH_ONTA);                                  // release rotation hold
            drawONTAPane (box);
            if (findPaneForChoice(PLOT_CH_ONTA) != PANE_NONE
                    && (fresh || spots_hash != prev_hash))
                scheduleMapRedraw();
        }
    } else {
        onta_ss.drawNewSpotsSymbol (false, false);                      // insure off either way
        ontaScrollToHome();
        ROTHOLD_CLR(PLOT_CH_ONTA);                                      // release any rotation hold
        plotMessage (box, RA8875_RED, "ONTA download error");
    }


    return (ok);
}

/* implement a tap at s known to be within the given box for our Pane.
 * a normal tap (TT_TAP) on a row engages it as before (QSY/bio/newDX); the secondary
 * tap (TT_TAP_BX, eg right-click) on a row instead offers to (re)spot it, a la Hunterlog.
 * return if something for us, else false to mean op wants to change the Pane option.
 */
bool checkOnTheAirTouch (TouchType tt, const SCoord &s, const SBox &box)
{
    // check for title or scroll
    if (s.y < box.y + PANETITLE_H) {

        if (onta_ss.checkScrollUpTouch (s, box)) {
            scrollONTAUp (box);
            return (true);
        }

        if (onta_ss.checkScrollDownTouch (s, box)) {
            scrollONTADown (box);
            return (true);
        }

        if (onta_ss.checkNewSpotsTouch (s, box)) {
            if (!ontaAtHome() && NEW_SPOTS()) {
                // scroll to home, let updateOnTheAir() do the rest
                onta_ss.drawNewSpotsSymbol (true, true);                // immediate feedback 
                ontaScrollToHome();
                scheduleNewPlot (PLOT_CH_ONTA);
            }
            return (true);                      // claim our even if not showing
        }

        // on hold?
        if (ROTHOLD_TST(PLOT_CH_ONTA))
            return (true);

        // else tapping title always leaves this pane
        return (false);
    }

    // check for tapping count to run menu -- but the small org-picker dropdown arrow within
    // this same row gets its own dedicated popup instead of the combined one
    if (s.y < box.y + LISTING_Y0) {
        if (inBox (s, onta_orgarrow_b))
            runONTAOrgMenu (box);
        else
            runONTASortMenu (box);
        return (true);
    }

    // tapped a row: secondary tap offers to (re)spot; a normal tap on the callsign
    // column specifically (only when it's actually truncated on screen) shows the
    // full callsign as a tooltip instead of engaging; normal tap elsewhere engages
    // exactly as before
    int spot_row;
    int vis_row = (s.y - (box.y + LISTING_Y0))/LISTING_DY;
    if (onta_ss.findDataIndex (vis_row, spot_row)) {
        DXSpot &sp = ontawl_spots[spot_row];
        if (tt == TT_TAP_BX) {
            runONTASpotMenu (box, sp);
        } else {
            int call_len = ontaCallLen (box);
            bool shown = false;
            if ((int)strlen(sp.tx_call) > call_len) {
                int freq_len = BOX_IS_PANE_0(box) ? ONTA_P0_FREQ_LEN : ONTA_PX_FREQ_LEN;
                uint16_t call_x0 = box.x + 1 + freq_len*ONTA_CHAR_W;
                uint16_t call_x1 = call_x0 + call_len*ONTA_CHAR_W;
                if (s.x >= call_x0 && s.x < call_x1) {
                    tooltip (s, sp.tx_call);
                    shown = true;
                }
            }
            if (!shown)
                engageONTARow (sp);
        }
    }

    // ours even if row is empty
    return (true);

}

/* pass back the ONTA spots list, and whether there are any at all.
 * N.B. caller must not modify the list
 */
bool getOnTheAirSpots (DXSpot **spp, uint8_t *nspotsp)
{
    // none if no spots or not showing
    if (!onta_spots || findPaneForChoice (PLOT_CH_ONTA) == PANE_NONE)
        return (false);

    // pass back
    *spp = onta_spots;
    *nspotsp = onta_ss.n_data;

    // ok
    return (true);
}

/* draw all filtered ONTA spots on the map
 */
void drawOnTheAirSpotsOnMap (void)
{
    if (ontawl_spots && findPaneForChoice (PLOT_CH_ONTA) != PANE_NONE) {
        for (int j = 0; j < onta_ss.n_data; j++) {
            drawSpotLabelOnMap (ontawl_spots[j], LOME_TXEND, LOMD_ALL);
        }
    }
}

/* find closest ontawl_spot and location on tx end to given ll (we don't use rx_ll), if any.
 */
bool getClosestOnTheAirSpot (LatLong &ll, DXSpot *onta_closest, LatLong *ll_closest)
{
    return (ontawl_spots && findPaneForChoice (PLOT_CH_ONTA) != PANE_NONE && getSpotLabelType() != LBL_NONE
            && getClosestSpot (ontawl_spots, onta_ss.n_data, NULL, LOME_TXEND, ll, onta_closest, ll_closest));
}

/* return spot in our pane if under ms 
 */
bool getOnTheAirPaneSpot (const SCoord &ms, DXSpot *dxs, LatLong *ll)
{
    // done if ms not showing our pane or not in our box
    PlotPane pp = findPaneChoiceNow (PLOT_CH_ONTA);
    if (pp == PANE_NONE)
        return (false);
    if (!inBox (ms, plot_b[pp]))
        return (false);

    // create box that will be placed over each listing entry
    SBox listrow_b;
    listrow_b.x = plot_b[pp].x;
    listrow_b.w = plot_b[pp].w;
    listrow_b.h = LISTING_DY;

    // scan listed spots for one located at ms
    uint16_t y0 = plot_b[pp].y + LISTING_Y0;
    int min_i, max_i;
    if (onta_ss.getVisDataIndices (min_i, max_i) > 0) {
        for (int i = min_i; i <= max_i; i++) {
            listrow_b.y = y0 + onta_ss.getDisplayRow(i) * LISTING_DY;
            if (inBox (ms, listrow_b)) {
                // ms is over this spot
                *dxs = ontawl_spots[i];
                *ll = dxs->tx_ll;
                return (true);
            }
        }
    }

    // none
    return (false);
}


/* return whether we are rotating through multiple organizations.
 * ALWAYS FALSE NOW: the old "type several orgs without a '+' to cycle through them one at a
 * time" behavior is retired now that org selection is a checkbox multi-select (onta_orgmask)
 * showing the union of everything checked, same as '+' used to mean -- there's no longer a
 * distinct "one at a time" mode to report on. Function kept (not removed) because
 * plotmgmnt.cpp calls it externally to decide whether to keep auto-cycling this pane's
 * display on a timer; always returning false is the correct answer to that question now.
 */
bool isONTARotating(void)
{
    return (false);
}
